# -----------------------------------------------------------------------
#             *** WARNING: DO NOT MODIFY THIS FILE ***
#
#         Instead, modify h2oai/service.proto and run "make proto".
# -----------------------------------------------------------------------

import time
import json
import requests
import os.path
import mimetypes
from typing import Any, List
from urllib.request import urlretrieve
from h2oai_client.messages import *
from tornado import gen, httpclient, ioloop
from functools import partial

class RequestError(Exception):
    def __init__(self, message: str):
        self.message = message

class RemoteError(Exception):
    def __init__(self, message: str):
        self.message = message

_secure_cookie_key="_h2oai_user"
class Client:
    def __init__(self, address: str, username: str, password: str, verify=True): #-> None:
        self.address = address
        self._verify = verify
        self._cid = 0
        res = requests.post(address + "/login", data=dict(username=username, password=password), verify=verify)
        if res.status_code != requests.codes.ok:
            raise RequestError("Authentication request failed {} (status={}): {}".format(self.address, res.status_code, res.text))

        for r in res.history:
            if _secure_cookie_key in r.cookies:
                self._cookies = {_secure_cookie_key: r.cookies[_secure_cookie_key]}
                return

        raise RequestError("Authentication unsuccessful. Unable to obtain authentication token.")

    def _request(self, method: str, params: dict) :#-> Any:

        self._cid = self._cid + 1
        req = json.dumps(dict(id=self._cid, method="api_" + method, params=params))
        res = requests.post(self.address + "/rpc", data=req, cookies=self._cookies, verify=self._verify)
        if res.status_code != requests.codes.ok:
            raise RequestError("Remote request failed {}#{} (status={}): ".format(self.address, method, res.status_code))

        response = res.json()
        if "error" in response:
            raise RemoteError(response["error"])

        return response["result"]

    def download(self, src_path: str, dest_dir: str):# -> str:
        dest_path = os.path.join(dest_dir, os.path.basename(src_path))
        url = self.address + "/files/" + src_path
        urlretrieve(url, dest_path)
        return dest_path


    #
    # NOTE: This python file is not used by the server at runtime.
    # These are extension methods that are appended to the h2oai_client module
    #   at development-time (via make proto).
    #
    # FIXME This is repetitive.

    def create_dataset_sync(self, filepath: str) : #-> Dataset:
        """Import a dataset.

        :param filepath: A path specifying the location of the data to upload.
        :returns: a new :class:`Dataset` instance.

        """

        key = self.create_dataset(filepath)
        job = self._wait_for_dataset(key)
        return job.entity

    def start_experiment_sync(self, dataset_key: str, target_col: str, is_classification: bool,
                              accuracy: int, time: int, interpretability: int, scorer: str = None, **kwargs) : #-> Model:
        r"""Start an experiment.

        :param dataset_key: Training dataset key
        :type dataset_key: ``str``
        :param target_col: Name of the targed column
        :type target_col: ``str``
        :param scorer: Name of one of the `available scorers` Default `None` - automatically decided
        :type scorer: ``str``
        :param is_classification: `True` for classification problem, `False` for regression
        :type is_classification: ``bool``
        :param accuracy: Accuracy setting [1-10]
        :param time: Time setting [1-10]
        :param interpretability: Interpretability setting [1-10]
        :param \**kwargs:
            See below

        :Keyword Arguments:
            * *validset_key* (``str``) --
                Validation daset key
            * *testset_key* (``str``) --
                Test daset key
            * *weight_col* (``str``) --
                Weights column name
            * *fold_col* (``str``) --
                Fold column name
            * *cols_to_drop* (``list``) --
                List of column to be dropped
            * *enable_gpus* (``bool``) --
                Allow GPU usage in experiment. Default `True`
            * *seed* (``int``) --
                Seed for PRNG. Default `False`
            * *time_col* (``str``) --
                Time column name, containing time ordering for timeseries problems
            * *is_timeseries* (``bool``) --
                Specifies whether problem is timeseries. Default `False`
            * *time_groups_columns* (``list``) --
                List of column names, contributing to time ordering
            * *time_period_in_seconds* (``int``) --
                Size of Lag features in seconds, used in timeseries problems
            * *num_prediction_periods* (``int``) --
                Timeseries forecast horizont in time period units
            * *num_gap_periods* (``int``) --
                Number of time periods after which forecast starts
            * *config_overrides* (``str``) --
                DriverlessAI config overrides for separate experiment in TOML string format
            * *resumed_model_key* (``str``) --
                Experiment key, used for retraining/re-ensembling/starting from checkpoint

        :returns: a new :class:`Model` instance.
        """
        params = ModelParameters(
            dataset_key=dataset_key,
            resumed_model_key=kwargs['resumed_model_key'] if 'resumed_model_key' in kwargs else '',
            target_col=target_col,
            weight_col=kwargs['weight_col'] if 'weight_col' in kwargs else None,
            fold_col=kwargs['fold_col'] if 'fold_col' in kwargs else None,
            orig_time_col=kwargs['orig_time_col'] if 'orig_time_col' in kwargs else kwargs['time_col'] if 'time_col' in kwargs else None,
            time_col=kwargs['time_col'] if 'time_col' in kwargs else None,
            is_classification=is_classification,
            cols_to_drop=kwargs['cols_to_drop'] if 'cols_to_drop' in kwargs else [],
            validset_key=kwargs['validset_key'] if 'validset_key' in kwargs else '',
            testset_key=kwargs['testset_key'] if 'testset_key' in kwargs else '',
            enable_gpus=kwargs['enable_gpus'] if 'enable_gpus' in kwargs else True,
            seed=kwargs['seed'] if 'seed' in kwargs else False,
            accuracy=accuracy,
            time=time,
            interpretability=interpretability,
            scorer=scorer,
            time_groups_columns=kwargs['time_groups_columns'] if 'time_groups_columns' in kwargs else None,
            time_period_in_seconds=kwargs['time_period_in_seconds'] if 'time_period_in_seconds' in kwargs else None,
            num_prediction_periods=kwargs['num_prediction_periods'] if 'num_prediction_periods' in kwargs else None,
            num_gap_periods=kwargs['num_gap_periods'] if 'num_gap_periods' in kwargs else None,
            is_timeseries=kwargs['is_timeseries'] if 'is_timeseries' in kwargs else False,
            config_overrides=kwargs['config_overrides'] if 'config_overrides' in kwargs else None
        )
        key = self.start_experiment(params)
        job = self._wait_for_model(key)
        return job.entity

    def make_prediction_sync(self, model_key: str, scoring_csv_path: str, output_margin: bool, pred_contribs: bool) : #-> Prediction:
        """Make a prediction from a model.

        :param model_key: Model key.
        :param scoring_csv_path: Path to send csv of predictions
        :param output_margin: Whether to return predictions as margins (in link space)
        :param pred_contribs: Whether to return prediction contributions
        :returns: a new :class:`Predictions` instance.

        """
        key = self.make_prediction(model_key, scoring_csv_path, output_margin, pred_contribs)
        job = self._wait_for_prediction(key)
        return job.entity

    def make_autoreport_sync(self, model_key: str, autoviz: bool, mli: bool) : #-> Prediction:
        """Make a prediction from a model.

        :param model_key: Model key.
        :param autoviz: Whether to return autoviz results
        :param mli: Whether to return mli results
        :returns: a new :class:`AutoReport` instance.

        """
        key = self.make_autoreport(model_key, autoviz, mli)
        job = self._wait_for_autoreport(key)
        return job.entity

    def fit_transform_batch_sync(self, model_key, training_input_csv_path, validation_input_csv_path, test_input_csv_path, validation_split_fraction, seed, fold_column) -> Transformation:
        key = self.fit_transform_batch(model_key, training_input_csv_path, validation_input_csv_path, test_input_csv_path, validation_split_fraction, seed, fold_column)
        job = self._wait_for_transformation(key)
        return job.entity

    def run_interpretation_sync(self, dai_model_key: str, dataset_key: str, target_col: str, **kwargs):
        r"""Run MLI.

        :param dai_model_key: DriverlessAI Model key, which will be interpreted
        :param dataset_key: Dataset key
        :param target_col: Target column name
        :param \**kwargs:
            See below

        :Keyword Arguments:
            * *use_raw_features* (``bool``) --
                Show interpretation based on the original columns. Default True
            * *weight_col* (``str``) --
                Weight column used by Driverless AI experiment
            * *drop_cols* (``list``) --
                List of columns not used for interpretation
            * *klime_cluster_col* (``str``) --
                Column used to split data into k-LIME clusters
            * *nfolds* (``int``) --
                Number of folds used by the surrogate models. Default 0
            * *sample* (``bool``) --
                Whether the training dataset should be sampled down for the interpretation
            * *sample_num_rows* (``int``) --
                Number of sampled rows. Default -1 == specified by config.toml
            * *qbin_cols* (``list``) --
                List of numeric columns to convert to quantile bins (can help fit surrogate models)
            * *qbin_count* (``int``) --
                Number of quantile bins for the quantile bin columns. Default 0
            * *lime_method* (``str``) --
                LIME method type from ['k-LIME', 'LIME_SUP']. Default 'k-LIME'
            * *dt_tree_depth* (``int``) --
                Max depth of decision tree surrogate model. Default 3
            * *config_overrides* (``str``) --
                DriverlessAI config overrides for separate experiment in TOML string format

        :returns: a new :class:`Interpretation` instance.
        """
        params = InterpretParameters(
            dai_model_key=dai_model_key,
            dataset_key=dataset_key,
            target_col=target_col,
            use_raw_features=kwargs['use_raw_features'] if 'use_raw_features' in kwargs else True,
            prediction_col=kwargs['prediction_col'] if 'prediction_col' in kwargs else '',
            weight_col=kwargs['weight_col'] if 'weight_col' in kwargs else '',
            drop_cols=kwargs['drop_cols'] if 'drop_cols' in kwargs else [],
            klime_cluster_col=kwargs['klime_cluster_col'] if 'klime_cluster_col' in kwargs else '',
            nfolds=kwargs['nfolds'] if 'nfolds' in kwargs else 0,
            sample=kwargs['sample'] if 'sample' in kwargs else True,
            sample_num_rows=kwargs['sample_num_rows'] if 'sample_num_rows' in kwargs else -1,
            qbin_cols=kwargs['qbin_cols'] if 'qbin_cols' in kwargs else [],
            qbin_count=kwargs['qbin_count'] if 'qbin_count' in kwargs else 0,
            lime_method=kwargs['lime_method'] if 'lime_method' in kwargs else "k-LIME",
            dt_tree_depth=kwargs['dt_tree_depth'] if 'dt_tree_depth' in kwargs else 3,
            config_overrides=kwargs['config_overrides'] if 'config_overrides' in kwargs else None
        )
        key = self.run_interpretation(params)
        job = self._wait_for_interpretation(key)
        return job.entity

    def run_model_diagnostics_sync(self, dai_model_key: str, **kwargs):
        r"""Run Model Diagnostics

        :param dai_model_key: DriverlessAI Model key with will run diagnostics on
        :param \**kwargs:
            See below

        :Keyword Arguments
            * *sample_num_rows* (``int``) --
               Number of rows to sample to generate metrics. Default -1 (All rows)

        :returns: a new :class: `ModelDiagnostics` instance.

        """

        params = ModelDiagnosticsParameters(
            dai_model_key=dai_model_key,
            testset_key=kwargs['testset_key'] if 'testset_key' in kwargs else '',
            sample_num_rows=kwargs['sample_num_rows'] if 'sample_num_rows' in kwargs else -1,
            config_overrides=""
        )
        key = self.run_model_diagnostics(params)
        job = self._wait_for_model_diagnostics(key)
        return job.entity

    def build_scoring_pipeline_sync(self, model_key: str) : #-> ScoringPipeline:
        """Build scoring pipeline.

        :param model_key: Model key.
        :returns: a new :class:`ScoringPipeline` instance.

        """
        key = self.build_scoring_pipeline(model_key)
        job = self._wait_for_scoring_pipeline(key)
        return job.entity

    def build_mojo_pipeline_sync(self, model_key: str) : #-> MOJOPipeline:
        """Build MOJO pipeline.

        :param model_key: Model key.
        :returns: a new :class:`ScoringPipeline` instance.

        """
        key = self.build_mojo_pipeline(model_key)
        job = self._wait_for_mojo_pipeline(key)
        return job.entity

    @gen.coroutine
    def tornado_raw_producer(self, filename, write):
        with open(filename, 'rb') as f:
            while True:
                # 1MB at a time.
                chunk = f.read(1024 * 1024)
                if not chunk:
                    # Complete.
                    break

                yield write(chunk)

    @gen.coroutine
    def do_tornado_upload(self, filename, skip_parse=False):
        url = self.address + "/streamupload"
        if skip_parse:
            url += "?noparse=1"

        client = httpclient.AsyncHTTPClient()
        mtype = mimetypes.guess_type(filename)[0] or 'application/octet-stream'
        headers = {'Content-Type': mtype, 'filename': filename}
        producer = partial(self.tornado_raw_producer, filename)
        response = yield client.fetch(url,
                                      method='PUT',
                                      headers=headers,
                                      body_producer=producer,
                                      request_timeout=3600)

    def perform_stream_upload(self, file_path, skip_parse=False):
        ioloop.IOLoop.current().run_sync(lambda: self.do_tornado_upload(file_path, skip_parse))

    def perform_upload(self, file_path, skip_parse=False):
        url = self.address + "/upload"
        if skip_parse:
            url += "?noparse=1"

        with open(file_path, 'rb') as f:
            res = requests.post(
                url,
                files={'dataset': f},
                cookies=self._cookies,
                verify=self._verify
            )

            if res.status_code == requests.codes.ok:
                return res.json()
            else:
                return None

    def upload_file_sync(self, file_path: str):
        """Upload a file.

        :param file_path: A path specifying the location of the file to upload.
        :returns: str: Absolute server-side path to the uploaded file.

        """
        return self.perform_stream_upload(file_path, skip_parse=True)

    def upload_dataset(self, file_path: str) : #-> str:
        """Upload a dataset

        :param file_path: A path specifying the location of the data to upload.
        :returns: str: REST response

        """
        return self.perform_upload(file_path)

    def upload_dataset_sync(self, file_path):
        """Upload a dataset and wait for the upload to complete.

        :param file_path: A path specifying the location of the file to upload.
        :returns: a Dataset instance.

        """
        keys = self.upload_dataset(file_path)
        job = self._wait_for_dataset(keys[0])
        return job.entity

    def create_dataset_from_hadoop_sync(self, filepath: str) : #-> Dataset:
        """Import a dataset.

        :param filepath: A path specifying the location of the data to upload.
        :returns: a new :class:`Dataset` instance.

        """

        key = self.create_dataset_from_hadoop(filepath)
        job = self._wait_for_dataset(key)
        return job.entity

    def create_dataset_from_s3_sync(self, filepath: str) : #-> Dataset:
        """Import a dataset.

        :param filepath: A path specifying the location of the data to upload.
        :returns: a new :class:`Dataset` instance.

        """

        key = self.create_dataset_from_s3(filepath)
        job = self._wait_for_dataset(key)
        return job.entity

    def create_dataset_from_minio_sync(self, filepath: str) : #-> Dataset:
        """Import a dataset from Minio.

        :param filepath: A path specifying the location of the data to upload.
        :returns: a new :class:`Dataset` instance.

        """

        key = self.create_dataset_from_minio(filepath)
        job = self._wait_for_dataset(key)
        return job.entity

    def create_dataset_from_gcs_sync(self, filepath: str): #-> Dataset:
        """Import a dataset from Google Cloud Storage.

        :param filepath: A path specifying the location of the data to upload.
        :returns: a new :class:`Dataset` instance.

        """

        key = self.create_dataset_from_gcs(filepath)
        job = self._wait_for_dataset(key)
        return job.entity

    def create_dataset_from_bigquery_sync(self, datasetid: str, dst: str, query: str): #-> Dataset:
        """Import a dataset using BigQuery Query

        :param datasetid: Name of BQ Dataset to use for tmp tables
        :param dst: destination filepath within GCS (gs://<bucket>/<file.csv>)
        :param query: SQL query to pass to BQ
        :returns a new :class:`Dataset` instance.
        """

        ret = self.create_bigquery_query(datasetid, dst, query)
        key = self.create_dataset_from_gcs(dst)
        job = self._wait_for_dataset(key)
        return job.entity

    def create_dataset_from_snowflake_sync(self, region: str, database: str, warehouse: str, schema: str, role: str, optional_file_formatting: str,  dst: str, query: str): #-> Dataset:
        """Import a dataset using Snowflake Query.

        :param region: (Optional) Region where Snowflake warehouse exists
        :param database: Name of Snowflake database to query
        :param warehouse: Name of Snowflake warehouse to query
        :param schema: Schema to use during query
        :param role: (Optional) Snowflake role to be used for query
        :param optional_file_formatting: (Optional) Additional arguments for formatting the output SQL query to csv file. See snowflake documentation for "Create File Format"
        :param dst: Destination within local file system for resulting dataset
        :param query: SQL query to pass to Snowflake
        """

        ret = self.create_snowflake_query(region, database, warehouse, schema, role, dst, query, optional_file_formatting)
        key = self.create_dataset(dst)
        job = self._wait_for_dataset(key)
        return job.entity

    def create_dataset_from_kdb_sync(self, destination: str, query: str):
        """Import a dataset using KDB+ Query.

        :param destination: Destination for KDB+ Query to be stored on the local filesystem
        :param query: KDB query. Use standard q queries.
        """

        key = self.create_dataset_from_kdb(destination, query)
        job = self._wait_for_dataset(key)
        return job.entity

    def get_experiment_preview_sync(self, dataset_key: str, validset_key: str, classification: bool,
                                    dropped_cols: List[str], target_col: str, is_time_series: bool,
                                    enable_gpus: bool, accuracy: int, time: int, interpretability: int,
                                    config_overrides: str):
        """Get explanation text for experiment settings

        :param str dataset_key: Training dataset key
        :param str validset_key: Validation dataset key if any
        :param bool classification: Indicating whether problem is classification or regression. Pass **True** for classification
        :param dropped_cols: List of column names, which won't be used in training
        :type dropped_cols: list of strings
        :param str target_col: Name of the target column for training
        :param bool is_time_series: Whether it's a time-series problem
        :param bool enable_gpus: Specifies whether experiment will use GPUs for training
        :param int accuracy: Accuracy parameter value
        :param int time: Time parameter value
        :param int interpretability: Interpretability parameter value
        :param str config_overrides: Raw config.toml file content (UTF8-encoded string)
        :returns: List of strings describing the experiment properties
        :rtype: list of strings

        """
        key = self.get_experiment_preview(
            dataset_key, validset_key, classification,
            dropped_cols, target_col, is_time_series,
            enable_gpus, accuracy, time, interpretability, config_overrides
        )
        job = self._wait_for_preview(key)
        return job.entity.lines


    # -------------------------------------Utility Functions-------------------------------------

    def _format_server_error(self, message):
        return 'Driverless AI Server reported an error: ' + message

    def _wait_for_dataset(self, key):
        while True:
            time.sleep(1)
            job = self.get_dataset_job(key)
            if job.status >= 0:  # done
                if job.status > 0:  # canceled or failed
                    raise RuntimeError(self._format_server_error(job.error))
                return job

    def _wait_for_model(self, key):
        while True:
            time.sleep(1)
            job = self.get_model_job(key)
            if job.status >= 0:  # done
                if job.status > 0:  # canceled or failed
                    raise RuntimeError(self._format_server_error(job.error))
                return job

    def _wait_for_prediction(self, key):
        while True:
            time.sleep(1)
            job = self.get_prediction_job(key)
            if job.status >= 0:  # done
                if job.status > 0:  # canceled or failed
                    raise RuntimeError(self._format_server_error(job.error))
                return job

    def _wait_for_autoreport(self, key):
        while True:
            time.sleep(1)
            job = self.get_autoreport_job(key)
            if job.status >= 0:  # done
                if job.status > 0:  # canceled or failed
                    raise RuntimeError(self._format_server_error(job.error))
                return job

    def _wait_for_transformation(self, key):
        while True:
            time.sleep(1)
            job = self.get_transformation_job(key)
            if job.status >= 0:  # done
                if job.status > 0:  # canceled or failed
                    raise RuntimeError(self._format_server_error(job.error))
                return job

    def _wait_for_interpretation(self, key):
        while True:
            time.sleep(1)
            job = self.get_interpretation_job(key)
            if job.status >= 0:  # done
                if job.status > 0:  # canceled or failed
                    raise RuntimeError(self._format_server_error(job.error))
                return job

    def _wait_for_model_diagnostics(self, key):
        while True:
            time.sleep(1)
            job = self.get_model_diagnostics_job(key)
            if job.status >= 0:  # done
                if job.status > 0:  # canceled or failed
                    raise RuntimeError(self._format_server_error(job.error))
                return job

    def _wait_for_scoring_pipeline(self, key):
        while True:
            time.sleep(1)
            job = self.get_scoring_pipeline_job(key)
            if job.status >= 0:  # done
                if job.status > 0:  # canceled or failed
                    raise RuntimeError(self._format_server_error(job.error))
                return job

    def _wait_for_mojo_pipeline(self, key):
        while True:
            time.sleep(1)
            job = self.get_mojo_pipeline_job(key)
            if job.status >= 0:  # done
                if job.status > 0:  # canceled or failed
                    raise RuntimeError(self._format_server_error(job.error))
                return job

    def _wait_for_preview(self, key):
        while True:
            time.sleep(1)
            job = self.get_experiment_preview_job(key)
            if job.status >= 0:  # done
                if job.status > 0:  # canceled or failed
                    raise RuntimeError(self._format_server_error(job.error))
                return job

    def start_echo(self, message: str, repeat: int) :#-> str:
        """

        """
        req_ = dict(message=message, repeat=repeat)
        res_ = self._request('start_echo', req_)
        return res_

    def stop_echo(self, key: str) :#-> None:
        """

        """
        req_ = dict(key=key)
        self._request('stop_echo', req_)
        return None

    def get_app_version(self) :#-> AppVersion:
        """
        Returns the application version.

        :returns: The application version.
        """
        req_ = dict()
        res_ = self._request('get_app_version', req_)
        return AppVersion.load(res_)

    def get_system_stats(self, force_cpu: bool) :#-> SystemStats:
        """
        Returns the server's system stats.

        :param force_cpu: Get CPU stats even if GPU is being utilized.
        :returns: The system stats.
        """
        req_ = dict(force_cpu=force_cpu)
        res_ = self._request('get_system_stats', req_)
        return SystemStats.load(res_)

    def start_experiment(self, req: ModelParameters) :#-> str:
        """
        Start a new experiment.

        :param req: The experiment's parameters.
        :returns: The experiment's key.
        """
        req_ = dict(req=req.dump())
        res_ = self._request('start_experiment', req_)
        return res_

    def stop_experiment(self, key: str) :#-> None:
        """
        Stop the experiment.

        :param key: The experiment's key.
        """
        req_ = dict(key=key)
        self._request('stop_experiment', req_)
        return None

    def abort_experiment(self, key: str) :#-> None:
        """
        Abort the experiment.

        :param key: The experiment's key.
        """
        req_ = dict(key=key)
        self._request('abort_experiment', req_)
        return None

    def list_datasets(self, offset: int, limit: int) :#-> List[DatasetSummary]:
        """

        """
        req_ = dict(offset=offset, limit=limit)
        res_ = self._request('list_datasets', req_)
        return [DatasetSummary.load(b_) for b_ in res_]

    def list_models(self, offset: int, limit: int) :#-> List[ModelSummary]:
        """

        """
        req_ = dict(offset=offset, limit=limit)
        res_ = self._request('list_models', req_)
        return [ModelSummary.load(b_) for b_ in res_]

    def list_diagnostics(self, offset: int, limit: int) :#-> List[ModelDiagnosticsSummary]:
        """

        """
        req_ = dict(offset=offset, limit=limit)
        res_ = self._request('list_diagnostics', req_)
        return [ModelDiagnosticsSummary.load(b_) for b_ in res_]

    def list_interpretations(self, offset: int, limit: int) :#-> List[InterpretSummary]:
        """

        """
        req_ = dict(offset=offset, limit=limit)
        res_ = self._request('list_interpretations', req_)
        return [InterpretSummary.load(b_) for b_ in res_]

    def list_visualizations(self, offset: int, limit: int) :#-> List[AutoVizSummary]:
        """

        """
        req_ = dict(offset=offset, limit=limit)
        res_ = self._request('list_visualizations', req_)
        return [AutoVizSummary.load(b_) for b_ in res_]

    def search_files(self, pattern: str) :#-> FileSearchResults:
        """

        """
        req_ = dict(pattern=pattern)
        res_ = self._request('search_files', req_)
        return FileSearchResults.load(res_)

    def search_hdfs_files(self, pattern: str) :#-> FileSearchResults:
        """

        """
        req_ = dict(pattern=pattern)
        res_ = self._request('search_hdfs_files', req_)
        return FileSearchResults.load(res_)

    def search_s3_files(self, pattern: str) :#-> FileSearchResults:
        """

        """
        req_ = dict(pattern=pattern)
        res_ = self._request('search_s3_files', req_)
        return FileSearchResults.load(res_)

    def search_gcs_files(self, pattern: str) :#-> FileSearchResults:
        """

        """
        req_ = dict(pattern=pattern)
        res_ = self._request('search_gcs_files', req_)
        return FileSearchResults.load(res_)

    def search_minio_files(self, pattern: str) :#-> FileSearchResults:
        """

        """
        req_ = dict(pattern=pattern)
        res_ = self._request('search_minio_files', req_)
        return FileSearchResults.load(res_)

    def copy_hdfs_to_local(self, src: str, dst: str) :#-> bool:
        """

        """
        req_ = dict(src=src, dst=dst)
        res_ = self._request('copy_hdfs_to_local', req_)
        return res_

    def create_kdb_query(self, dst: str, query: str) :#-> bool:
        """

        """
        req_ = dict(dst=dst, query=query)
        res_ = self._request('create_kdb_query', req_)
        return res_

    def create_dataset_from_kdb(self, dst: str, query: str) :#-> str:
        """

        """
        req_ = dict(dst=dst, query=query)
        res_ = self._request('create_dataset_from_kdb', req_)
        return res_

    def copy_s3_to_local(self, src: str, dst: str) :#-> bool:
        """

        """
        req_ = dict(src=src, dst=dst)
        res_ = self._request('copy_s3_to_local', req_)
        return res_

    def list_s3_buckets(self, offset: int, limit: int) :#-> List[str]:
        """

        """
        req_ = dict(offset=offset, limit=limit)
        res_ = self._request('list_s3_buckets', req_)
        return res_

    def copy_gcs_to_local(self, src: str, dst: str) :#-> bool:
        """

        """
        req_ = dict(src=src, dst=dst)
        res_ = self._request('copy_gcs_to_local', req_)
        return res_

    def list_gcs_buckets(self, offset: int, limit: int) :#-> List[str]:
        """

        """
        req_ = dict(offset=offset, limit=limit)
        res_ = self._request('list_gcs_buckets', req_)
        return res_

    def copy_minio_to_local(self, src: str, dst: str) :#-> bool:
        """

        """
        req_ = dict(src=src, dst=dst)
        res_ = self._request('copy_minio_to_local', req_)
        return res_

    def list_minio_buckets(self, offset: int, limit: int) :#-> List[str]:
        """

        """
        req_ = dict(offset=offset, limit=limit)
        res_ = self._request('list_minio_buckets', req_)
        return res_

    def create_bigquery_query(self, dataset_id: str, dst: str, query: str) :#-> bool:
        """

        """
        req_ = dict(dataset_id=dataset_id, dst=dst, query=query)
        res_ = self._request('create_bigquery_query', req_)
        return res_

    def create_snowflake_query(self, region: str, database: str, warehouse: str, schema: str, role: str, dst: str, query: str, optional_file_formatting: str) :#-> bool:
        """

        """
        req_ = dict(region=region, database=database, warehouse=warehouse, schema=schema, role=role, dst=dst, query=query, optional_file_formatting=optional_file_formatting)
        res_ = self._request('create_snowflake_query', req_)
        return res_

    def list_allowed_file_systems(self, offset: int, limit: int) :#-> List[str]:
        """

        """
        req_ = dict(offset=offset, limit=limit)
        res_ = self._request('list_allowed_file_systems', req_)
        return res_

    def create_dataset(self, filepath: str) :#-> str:
        """

        """
        req_ = dict(filepath=filepath)
        res_ = self._request('create_dataset', req_)
        return res_

    def create_dataset_from_hadoop(self, file_path: str) :#-> str:
        """

        """
        req_ = dict(file_path=file_path)
        res_ = self._request('create_dataset_from_hadoop', req_)
        return res_

    def create_dataset_from_s3(self, file_path: str) :#-> str:
        """

        """
        req_ = dict(file_path=file_path)
        res_ = self._request('create_dataset_from_s3', req_)
        return res_

    def create_dataset_from_gcs(self, filepath: str) :#-> str:
        """

        """
        req_ = dict(filepath=filepath)
        res_ = self._request('create_dataset_from_gcs', req_)
        return res_

    def create_dataset_from_minio(self, filepath: str) :#-> str:
        """

        """
        req_ = dict(filepath=filepath)
        res_ = self._request('create_dataset_from_minio', req_)
        return res_

    def delete_dataset(self, key: str) :#-> None:
        """

        """
        req_ = dict(key=key)
        self._request('delete_dataset', req_)
        return None

    def get_dataset_job(self, key: str) :#-> DatasetJob:
        """

        """
        req_ = dict(key=key)
        res_ = self._request('get_dataset_job', req_)
        return DatasetJob.load(res_)

    def delete_model(self, key: str) :#-> None:
        """

        """
        req_ = dict(key=key)
        self._request('delete_model', req_)
        return None

    def delete_interpretation(self, key: str) :#-> None:
        """

        """
        req_ = dict(key=key)
        self._request('delete_interpretation', req_)
        return None

    def import_model(self, filepath: str) :#-> str:
        """

        """
        req_ = dict(filepath=filepath)
        res_ = self._request('import_model', req_)
        return res_

    def get_importmodel_job(self, key: str) :#-> ImportModelJob:
        """

        """
        req_ = dict(key=key)
        res_ = self._request('get_importmodel_job', req_)
        return ImportModelJob.load(res_)

    def get_dataset_summary(self, key: str) :#-> DatasetSummary:
        """

        """
        req_ = dict(key=key)
        res_ = self._request('get_dataset_summary', req_)
        return DatasetSummary.load(res_)

    def get_model_job(self, key: str) :#-> ModelJob:
        """

        """
        req_ = dict(key=key)
        res_ = self._request('get_model_job', req_)
        return ModelJob.load(res_)

    def get_variable_importance(self, key: str) :#-> VarImpTable:
        """

        """
        req_ = dict(key=key)
        res_ = self._request('get_variable_importance', req_)
        return VarImpTable.load(res_)

    def get_model_job_partial(self, key: str, from_iteration: int) :#-> ModelJob:
        """

        """
        req_ = dict(key=key, from_iteration=from_iteration)
        res_ = self._request('get_model_job_partial', req_)
        return ModelJob.load(res_)

    def get_model_summary(self, key: str) :#-> ModelSummary:
        """

        """
        req_ = dict(key=key)
        res_ = self._request('get_model_summary', req_)
        return ModelSummary.load(res_)

    def update_model_description(self, key: str, new_description: str) :#-> None:
        """

        """
        req_ = dict(key=key, new_description=new_description)
        self._request('update_model_description', req_)
        return None

    def update_mli_description(self, key: str, new_description: str) :#-> None:
        """

        """
        req_ = dict(key=key, new_description=new_description)
        self._request('update_mli_description', req_)
        return None

    def get_autoviz(self, dataset_key: str, maximum_number_of_plots: int) :#-> str:
        """

        """
        req_ = dict(dataset_key=dataset_key, maximum_number_of_plots=maximum_number_of_plots)
        res_ = self._request('get_autoviz', req_)
        return res_

    def get_autoviz_summary(self, key: str) :#-> AutoVizSummary:
        """

        """
        req_ = dict(key=key)
        res_ = self._request('get_autoviz_summary', req_)
        return AutoVizSummary.load(res_)

    def get_scatterplot(self, dataset_key: str, x_variable_name: str, y_variable_name: str) :#-> str:
        """

        """
        req_ = dict(dataset_key=dataset_key, x_variable_name=x_variable_name, y_variable_name=y_variable_name)
        res_ = self._request('get_scatterplot', req_)
        return res_

    def get_scatterplot_job(self, key: str) :#-> ScatterPlotJob:
        """

        """
        req_ = dict(key=key)
        res_ = self._request('get_scatterplot_job', req_)
        return ScatterPlotJob.load(res_)

    def get_histogram(self, dataset_key: str, variable_name: str, number_of_bars: Any) :#-> str:
        """

        """
        req_ = dict(dataset_key=dataset_key, variable_name=variable_name, number_of_bars=number_of_bars)
        res_ = self._request('get_histogram', req_)
        return res_

    def get_histogram_job(self, key: str) :#-> HistogramJob:
        """

        """
        req_ = dict(key=key)
        res_ = self._request('get_histogram_job', req_)
        return HistogramJob.load(res_)

    def get_vis_stats(self, dataset_key: str) :#-> str:
        """

        """
        req_ = dict(dataset_key=dataset_key)
        res_ = self._request('get_vis_stats', req_)
        return res_

    def get_vis_stats_job(self, key: str) :#-> VisStatsJob:
        """

        """
        req_ = dict(key=key)
        res_ = self._request('get_vis_stats_job', req_)
        return VisStatsJob.load(res_)

    def get_boxplot(self, dataset_key: str, variable_name: str) :#-> str:
        """

        """
        req_ = dict(dataset_key=dataset_key, variable_name=variable_name)
        res_ = self._request('get_boxplot', req_)
        return res_

    def get_boxplot_job(self, key: str) :#-> BoxplotJob:
        """

        """
        req_ = dict(key=key)
        res_ = self._request('get_boxplot_job', req_)
        return BoxplotJob.load(res_)

    def get_grouped_boxplot(self, datset_key: str, variable_name: str, group_variable_name: str) :#-> str:
        """

        """
        req_ = dict(datset_key=datset_key, variable_name=variable_name, group_variable_name=group_variable_name)
        res_ = self._request('get_grouped_boxplot', req_)
        return res_

    def get_grouped_boxplot_job(self, key: str) :#-> BoxplotJob:
        """

        """
        req_ = dict(key=key)
        res_ = self._request('get_grouped_boxplot_job', req_)
        return BoxplotJob.load(res_)

    def get_dotplot(self, key: str, variable_name: str, digits: int) :#-> str:
        """

        """
        req_ = dict(key=key, variable_name=variable_name, digits=digits)
        res_ = self._request('get_dotplot', req_)
        return res_

    def get_dotplot_job(self, key: str) :#-> DotplotJob:
        """

        """
        req_ = dict(key=key)
        res_ = self._request('get_dotplot_job', req_)
        return DotplotJob.load(res_)

    def get_parallel_coordinates_plot(self, key: str, variable_names: List[str]) :#-> str:
        """

        """
        req_ = dict(key=key, variable_names=variable_names)
        res_ = self._request('get_parallel_coordinates_plot', req_)
        return res_

    def get_parallel_coordinates_plot_job(self, key: str) :#-> ParallelCoordinatesPlotJob:
        """

        """
        req_ = dict(key=key)
        res_ = self._request('get_parallel_coordinates_plot_job', req_)
        return ParallelCoordinatesPlotJob.load(res_)

    def get_heatmap(self, key: str, variable_names: List[str], matrix_type: str, normalize: bool, permute: bool, missing: bool) :#-> str:
        """

        """
        req_ = dict(key=key, variable_names=variable_names, matrix_type=matrix_type, normalize=normalize, permute=permute, missing=missing)
        res_ = self._request('get_heatmap', req_)
        return res_

    def get_heatmap_job(self, key: str) :#-> HeatMapJob:
        """

        """
        req_ = dict(key=key)
        res_ = self._request('get_heatmap_job', req_)
        return HeatMapJob.load(res_)

    def get_scale(self, dataset_key: str, data_min: float, data_max: float) :#-> H2OScale:
        """

        """
        req_ = dict(dataset_key=dataset_key, data_min=data_min, data_max=data_max)
        res_ = self._request('get_scale', req_)
        return H2OScale.load(res_)

    def get_outliers(self, dataset_key: str, variable_names: List[str], alpha: float) :#-> str:
        """

        """
        req_ = dict(dataset_key=dataset_key, variable_names=variable_names, alpha=alpha)
        res_ = self._request('get_outliers', req_)
        return res_

    def get_outliers_job(self, key: str) :#-> OutliersJob:
        """

        """
        req_ = dict(key=key)
        res_ = self._request('get_outliers_job', req_)
        return OutliersJob.load(res_)

    def get_barchart(self, dataset_key: str, variable_name: str) :#-> str:
        """

        """
        req_ = dict(dataset_key=dataset_key, variable_name=variable_name)
        res_ = self._request('get_barchart', req_)
        return res_

    def get_barchart_job(self, key: str) :#-> BarchartJob:
        """

        """
        req_ = dict(key=key)
        res_ = self._request('get_barchart_job', req_)
        return BarchartJob.load(res_)

    def get_network(self, dataset_key: str, matrix_type: str, normalize: bool) :#-> str:
        """

        """
        req_ = dict(dataset_key=dataset_key, matrix_type=matrix_type, normalize=normalize)
        res_ = self._request('get_network', req_)
        return res_

    def get_network_job(self, key: str) :#-> NetworkJob:
        """

        """
        req_ = dict(key=key)
        res_ = self._request('get_network_job', req_)
        return NetworkJob.load(res_)

    def list_scorers(self) :#-> List[Scorer]:
        """

        """
        req_ = dict()
        res_ = self._request('list_scorers', req_)
        return [Scorer.load(b_) for b_ in res_]

    def get_model_trace(self, key: str, offset: int, limit: int) :#-> ModelTraceEvents:
        """

        """
        req_ = dict(key=key, offset=offset, limit=limit)
        res_ = self._request('get_model_trace', req_)
        return ModelTraceEvents.load(res_)

    def make_prediction(self, model_key: str, scoring_csv_path: str, output_margin: bool, pred_contribs: bool) :#-> str:
        """

        """
        req_ = dict(model_key=model_key, scoring_csv_path=scoring_csv_path, output_margin=output_margin, pred_contribs=pred_contribs)
        res_ = self._request('make_prediction', req_)
        return res_

    def get_prediction_job(self, key: str) :#-> PredictionJob:
        """

        """
        req_ = dict(key=key)
        res_ = self._request('get_prediction_job', req_)
        return PredictionJob.load(res_)

    def make_autoreport(self, model_key: str, autoviz: bool, mli: bool) :#-> str:
        """

        """
        req_ = dict(model_key=model_key, autoviz=autoviz, mli=mli)
        res_ = self._request('make_autoreport', req_)
        return res_

    def get_autoreport_job(self, key: str) :#-> AutoReportJob:
        """

        """
        req_ = dict(key=key)
        res_ = self._request('get_autoreport_job', req_)
        return AutoReportJob.load(res_)

    def fit_transform_batch(self, model_key: str, training_input_csv_path: str, validation_input_csv_path: str, test_input_csv_path: str, validation_split_fraction: float, seed: int, fold_column: str) :#-> str:
        """

        """
        req_ = dict(model_key=model_key, training_input_csv_path=training_input_csv_path, validation_input_csv_path=validation_input_csv_path, test_input_csv_path=test_input_csv_path, validation_split_fraction=validation_split_fraction, seed=seed, fold_column=fold_column)
        res_ = self._request('fit_transform_batch', req_)
        return res_

    def get_transformation_job(self, key: str) :#-> TransformationJob:
        """

        """
        req_ = dict(key=key)
        res_ = self._request('get_transformation_job', req_)
        return TransformationJob.load(res_)

    def run_model_diagnostics(self, model_diagnostics_params: ModelDiagnosticsParameters) :#-> str:
        """

        """
        req_ = dict(model_diagnostics_params=model_diagnostics_params.dump())
        res_ = self._request('run_model_diagnostics', req_)
        return res_

    def get_model_diagnostics_job(self, key: str) :#-> ModelDiagnosticsJob:
        """

        """
        req_ = dict(key=key)
        res_ = self._request('get_model_diagnostics_job', req_)
        return ModelDiagnosticsJob.load(res_)

    def get_model_diagnostics_summary(self, key: str) :#-> ModelDiagnosticsSummary:
        """

        """
        req_ = dict(key=key)
        res_ = self._request('get_model_diagnostics_summary', req_)
        return ModelDiagnosticsSummary.load(res_)

    def run_interpretation(self, interpret_params: InterpretParameters) :#-> str:
        """

        """
        req_ = dict(interpret_params=interpret_params.dump())
        res_ = self._request('run_interpretation', req_)
        return res_

    def get_interpretation_job(self, key: str) :#-> InterpretationJob:
        """

        """
        req_ = dict(key=key)
        res_ = self._request('get_interpretation_job', req_)
        return InterpretationJob.load(res_)

    def get_interpretation_summary(self, key: str) :#-> InterpretSummary:
        """

        """
        req_ = dict(key=key)
        res_ = self._request('get_interpretation_summary', req_)
        return InterpretSummary.load(res_)

    def build_scoring_pipeline(self, model_key: str) :#-> str:
        """

        """
        req_ = dict(model_key=model_key)
        res_ = self._request('build_scoring_pipeline', req_)
        return res_

    def build_mojo_pipeline(self, model_key: str) :#-> str:
        """

        """
        req_ = dict(model_key=model_key)
        res_ = self._request('build_mojo_pipeline', req_)
        return res_

    def get_scoring_pipeline_job(self, key: str) :#-> ScoringPipelineJob:
        """

        """
        req_ = dict(key=key)
        res_ = self._request('get_scoring_pipeline_job', req_)
        return ScoringPipelineJob.load(res_)

    def get_mojo_pipeline_job(self, key: str) :#-> MojoPipelineJob:
        """

        """
        req_ = dict(key=key)
        res_ = self._request('get_mojo_pipeline_job', req_)
        return MojoPipelineJob.load(res_)

    def get_autoviz_job(self, key: str) :#-> AutoVizJob:
        """

        """
        req_ = dict(key=key)
        res_ = self._request('get_autoviz_job', req_)
        return AutoVizJob.load(res_)

    def delete_autoviz_job(self, key: str) :#-> None:
        """

        """
        req_ = dict(key=key)
        self._request('delete_autoviz_job', req_)
        return None

    def delete_plot(self, typ: str, key: str) :#-> None:
        """

        """
        req_ = dict(typ=typ, key=key)
        self._request('delete_plot', req_)
        return None

    def have_valid_license(self) :#-> License:
        """

        """
        req_ = dict()
        res_ = self._request('have_valid_license', req_)
        return License.load(res_)

    def is_valid_license_key(self, license_key: str) :#-> License:
        """

        """
        req_ = dict(license_key=license_key)
        res_ = self._request('is_valid_license_key', req_)
        return License.load(res_)

    def save_license_key(self, license_key: str) :#-> License:
        """

        """
        req_ = dict(license_key=license_key)
        res_ = self._request('save_license_key', req_)
        return License.load(res_)

    def get_frame_rows(self, frame_name: str, row_offset: int, num_rows: int, job_key: str) :#-> str:
        """

        """
        req_ = dict(frame_name=frame_name, row_offset=row_offset, num_rows=num_rows, job_key=job_key)
        res_ = self._request('get_frame_rows', req_)
        return res_

    def query_datatable(self, frame_name: str, query_str: str, job_key: str) :#-> str:
        """

        """
        req_ = dict(frame_name=frame_name, query_str=query_str, job_key=job_key)
        res_ = self._request('query_datatable', req_)
        return res_

    def get_json(self, json_name: str, job_key: str) :#-> str:
        """

        """
        req_ = dict(json_name=json_name, job_key=job_key)
        res_ = self._request('get_json', req_)
        return res_

    def get_individual_conditional_expectation(self, row_offset: int, job_key: str) :#-> str:
        """

        """
        req_ = dict(row_offset=row_offset, job_key=job_key)
        res_ = self._request('get_individual_conditional_expectation', req_)
        return res_

    def track_subsystem_event(self, subsystem_name: str, event_name: str) :#-> None:
        """

        """
        req_ = dict(subsystem_name=subsystem_name, event_name=event_name)
        self._request('track_subsystem_event', req_)
        return None

    def get_raw_data(self, key: str, offset: int, limit: int) :#-> ExemplarRowsResponse:
        """

        """
        req_ = dict(key=key, offset=offset, limit=limit)
        res_ = self._request('get_raw_data', req_)
        return ExemplarRowsResponse.load(res_)

    def get_exemplar_rows(self, key: str, exemplar_id: int, offset: int, limit: int, variable_id: int) :#-> ExemplarRowsResponse:
        """

        """
        req_ = dict(key=key, exemplar_id=exemplar_id, offset=offset, limit=limit, variable_id=variable_id)
        res_ = self._request('get_exemplar_rows', req_)
        return ExemplarRowsResponse.load(res_)

    def get_experiment_tuning_suggestion(self, dataset_key: str, target_col: str, is_classification: bool, is_time_series: bool, config_overrides: str) :#-> ModelParameters:
        """

        """
        req_ = dict(dataset_key=dataset_key, target_col=target_col, is_classification=is_classification, is_time_series=is_time_series, config_overrides=config_overrides)
        res_ = self._request('get_experiment_tuning_suggestion', req_)
        return ModelParameters.load(res_)

    def get_experiment_preview(self, dataset_key: str, validset_key: str, classification: bool, dropped_cols: List[str], target_col: str, is_time_series: bool, enable_gpus: bool, accuracy: int, time: int, interpretability: int, config_overrides: str) :#-> str:
        """

        """
        req_ = dict(dataset_key=dataset_key, validset_key=validset_key, classification=classification, dropped_cols=dropped_cols, target_col=target_col, is_time_series=is_time_series, enable_gpus=enable_gpus, accuracy=accuracy, time=time, interpretability=interpretability, config_overrides=config_overrides)
        res_ = self._request('get_experiment_preview', req_)
        return res_

    def get_experiment_preview_job(self, key: str) :#-> ExperimentPreviewJob:
        """

        """
        req_ = dict(key=key)
        res_ = self._request('get_experiment_preview_job', req_)
        return ExperimentPreviewJob.load(res_)

    def get_current_user_info(self) :#-> UserInfo:
        """

        """
        req_ = dict()
        res_ = self._request('get_current_user_info', req_)
        return UserInfo.load(res_)

    def get_timeseries_split_suggestion(self, train_key: str, time_col: str, time_groups_columns: List[str], test_key: str) :#-> str:
        """

        """
        req_ = dict(train_key=train_key, time_col=time_col, time_groups_columns=time_groups_columns, test_key=test_key)
        res_ = self._request('get_timeseries_split_suggestion', req_)
        return res_

    def get_timeseries_split_suggestion_job(self, key: str) :#-> TimeSeriesSplitSuggestionJob:
        """

        """
        req_ = dict(key=key)
        res_ = self._request('get_timeseries_split_suggestion_job', req_)
        return TimeSeriesSplitSuggestionJob.load(res_)
