# -----------------------------------------------------------------------
#             *** WARNING: DO NOT MODIFY THIS FILE ***
#
#         Instead, modify h2oai/service.proto and run "make proto".
# -----------------------------------------------------------------------

from typing import List, Any

class EchoStatus:
    """

    """
    def __init__(self, progress, message) :#-> None:
        self.progress = progress
        self.message = message

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'EchoStatus':
        return EchoStatus(self.progress, self.message)

    @staticmethod
    def load(d: dict) :#-> 'EchoStatus':
        return EchoStatus(**d)


class License:
    """
    Represents a license key.

    :param is_valid: Is this license valid?
    :param message: License message.
    :param days_left: Days left before license expires.
    :param plaintext_key: License key.
    :param save_succeeded: Whether the license was applied successfully.
    :param organization: Organization that obtained the license
    :param serial_number: Serial number of the license
    :param license_type: License type ("developer", "trial", "pilot", "production", "cloud").
    """
    def __init__(self, is_valid, message, days_left, plaintext_key, save_succeeded, organization, serial_number, license_type) :#-> None:
        self.is_valid = is_valid
        self.message = message
        self.days_left = days_left
        self.plaintext_key = plaintext_key
        self.save_succeeded = save_succeeded
        self.organization = organization
        self.serial_number = serial_number
        self.license_type = license_type

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'License':
        return License(self.is_valid, self.message, self.days_left, self.plaintext_key, self.save_succeeded, self.organization, self.serial_number, self.license_type)

    @staticmethod
    def load(d: dict) :#-> 'License':
        return License(**d)


class AppVersion:
    """
    The application version.

    :param version: The application version (semver).
    :param build: The application build number.
    :param license: The license associated with this instance.
    :param config: List of expert configurable options for experiments
    """
    def __init__(self, version, build, license, config, notification_url, s3_init_path) :#-> None:
        self.version = version
        self.build = build
        self.license = license
        self.config = config
        self.notification_url = notification_url
        self.s3_init_path = s3_init_path

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['license'] = self.license.dump()
        d['config'] = [a.dump() for a in self.config]
        return d

    def clone(self) :#-> 'AppVersion':
        return AppVersion(self.version, self.build, self.license, self.config, self.notification_url, self.s3_init_path)

    @staticmethod
    def load(d: dict) :#-> 'AppVersion':
        d['license'] = License.load(d['license'])
        d['config'] = [ConfigItem.load(a) for a in d['config']]
        return AppVersion(**d)


class H2OVisAggregation:
    """

    """
    def __init__(self, aggregated_frame, mapping_frame) :#-> None:
        self.aggregated_frame = aggregated_frame
        self.mapping_frame = mapping_frame

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'H2OVisAggregation':
        return H2OVisAggregation(self.aggregated_frame, self.mapping_frame)

    @staticmethod
    def load(d: dict) :#-> 'H2OVisAggregation':
        return H2OVisAggregation(**d)


class H2OVisStats:
    """

    """
    def __init__(self, number_of_columns, number_of_rows, column_names, column_is_categorical) :#-> None:
        self.number_of_columns = number_of_columns
        self.number_of_rows = number_of_rows
        self.column_names = column_names
        self.column_is_categorical = column_is_categorical

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'H2OVisStats':
        return H2OVisStats(self.number_of_columns, self.number_of_rows, self.column_names, self.column_is_categorical)

    @staticmethod
    def load(d: dict) :#-> 'H2OVisStats':
        return H2OVisStats(**d)


class H2OParallelCoordinatesPlot:
    """

    """
    def __init__(self, variable_names, profiles, counts, is_categorical, cluster_indices, data_min_max) :#-> None:
        self.variable_names = variable_names
        self.profiles = profiles
        self.counts = counts
        self.is_categorical = is_categorical
        self.cluster_indices = cluster_indices
        self.data_min_max = data_min_max

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'H2OParallelCoordinatesPlot':
        return H2OParallelCoordinatesPlot(self.variable_names, self.profiles, self.counts, self.is_categorical, self.cluster_indices, self.data_min_max)

    @staticmethod
    def load(d: dict) :#-> 'H2OParallelCoordinatesPlot':
        return H2OParallelCoordinatesPlot(**d)


class H2OHeatMap:
    """

    """
    def __init__(self, column_names, columns, number_of_columns, number_of_rows, counts) :#-> None:
        self.column_names = column_names
        self.columns = columns
        self.number_of_columns = number_of_columns
        self.number_of_rows = number_of_rows
        self.counts = counts

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'H2OHeatMap':
        return H2OHeatMap(self.column_names, self.columns, self.number_of_columns, self.number_of_rows, self.counts)

    @staticmethod
    def load(d: dict) :#-> 'H2OHeatMap':
        return H2OHeatMap(**d)


class NoGroupVariable:
    """

    """
    def __init__(self, upper_hinge, median, lower_hinge, extreme_outliers, outliers, lower_adjacent_value, upper_adjacent_value) :#-> None:
        self.upper_hinge = upper_hinge
        self.median = median
        self.lower_hinge = lower_hinge
        self.extreme_outliers = extreme_outliers
        self.outliers = outliers
        self.lower_adjacent_value = lower_adjacent_value
        self.upper_adjacent_value = upper_adjacent_value

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'NoGroupVariable':
        return NoGroupVariable(self.upper_hinge, self.median, self.lower_hinge, self.extreme_outliers, self.outliers, self.lower_adjacent_value, self.upper_adjacent_value)

    @staticmethod
    def load(d: dict) :#-> 'NoGroupVariable':
        return NoGroupVariable(**d)


class H2OBoxplotEnvelope:
    """

    """
    def __init__(self, no_group_variable) :#-> None:
        self.no_group_variable = no_group_variable

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['no_group_variable'] = self.no_group_variable.dump()
        return d

    def clone(self) :#-> 'H2OBoxplotEnvelope':
        return H2OBoxplotEnvelope(self.no_group_variable)

    @staticmethod
    def load(d: dict) :#-> 'H2OBoxplotEnvelope':
        d['no_group_variable'] = NoGroupVariable.load(d['no_group_variable'])
        return H2OBoxplotEnvelope(**d)


class H2OBoxplot:
    """

    """
    def __init__(self, boxplots, variable_name) :#-> None:
        self.boxplots = boxplots
        self.variable_name = variable_name

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'H2OBoxplot':
        return H2OBoxplot(self.boxplots, self.variable_name)

    @staticmethod
    def load(d: dict) :#-> 'H2OBoxplot':
        return H2OBoxplot(**d)


class Histogram:
    """

    """
    def __init__(self, counts, variable_name, number_of_bars, number_of_ticks, scale_max, scale_min) :#-> None:
        self.counts = counts
        self.variable_name = variable_name
        self.number_of_bars = number_of_bars
        self.number_of_ticks = number_of_ticks
        self.scale_max = scale_max
        self.scale_min = scale_min

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'Histogram':
        return Histogram(self.counts, self.variable_name, self.number_of_bars, self.number_of_ticks, self.scale_max, self.scale_min)

    @staticmethod
    def load(d: dict) :#-> 'Histogram':
        return Histogram(**d)


class H2OScale:
    """

    """
    def __init__(self, scale_min, scale_max, number_of_ticks) :#-> None:
        self.scale_min = scale_min
        self.scale_max = scale_max
        self.number_of_ticks = number_of_ticks

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'H2OScale':
        return H2OScale(self.scale_min, self.scale_max, self.number_of_ticks)

    @staticmethod
    def load(d: dict) :#-> 'H2OScale':
        return H2OScale(**d)


class H2OOutliers:
    """

    """
    def __init__(self, row_indices) :#-> None:
        self.row_indices = row_indices

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'H2OOutliers':
        return H2OOutliers(self.row_indices)

    @staticmethod
    def load(d: dict) :#-> 'H2OOutliers':
        return H2OOutliers(**d)


class H2OPlot:
    """

    """
    def __init__(self, x_variable_name, x_values, y_variable_name, y_values, counts) :#-> None:
        self.x_variable_name = x_variable_name
        self.x_values = x_values
        self.y_variable_name = y_variable_name
        self.y_values = y_values
        self.counts = counts

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'H2OPlot':
        return H2OPlot(self.x_variable_name, self.x_values, self.y_variable_name, self.y_values, self.counts)

    @staticmethod
    def load(d: dict) :#-> 'H2OPlot':
        return H2OPlot(**d)


class H2ODotplot:
    """

    """
    def __init__(self, stacks, variable_name, x_values, scale_min, scale_max, histogram, outliers) :#-> None:
        self.stacks = stacks
        self.variable_name = variable_name
        self.x_values = x_values
        self.scale_min = scale_min
        self.scale_max = scale_max
        self.histogram = histogram
        self.outliers = outliers

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['histogram'] = self.histogram.dump()
        d['outliers'] = self.outliers.dump()
        return d

    def clone(self) :#-> 'H2ODotplot':
        return H2ODotplot(self.stacks, self.variable_name, self.x_values, self.scale_min, self.scale_max, self.histogram, self.outliers)

    @staticmethod
    def load(d: dict) :#-> 'H2ODotplot':
        d['histogram'] = Histogram.load(d['histogram'])
        d['outliers'] = H2OOutliers.load(d['outliers'])
        return H2ODotplot(**d)


class H2ONetwork:
    """

    """
    def __init__(self, edges, edge_weights, nodes) :#-> None:
        self.edges = edges
        self.edge_weights = edge_weights
        self.nodes = nodes

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'H2ONetwork':
        return H2ONetwork(self.edges, self.edge_weights, self.nodes)

    @staticmethod
    def load(d: dict) :#-> 'H2ONetwork':
        return H2ONetwork(**d)


class H2OBarchart:
    """

    """
    def __init__(self, x_values, y_values, x_variable_name) :#-> None:
        self.x_values = x_values
        self.y_values = y_values
        self.x_variable_name = x_variable_name

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'H2OBarchart':
        return H2OBarchart(self.x_values, self.y_values, self.x_variable_name)

    @staticmethod
    def load(d: dict) :#-> 'H2OBarchart':
        return H2OBarchart(**d)


class AutoVizScatterplot:
    """

    """
    def __init__(self, clumpy, correlated, unusual) :#-> None:
        self.clumpy = clumpy
        self.correlated = correlated
        self.unusual = unusual

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'AutoVizScatterplot':
        return AutoVizScatterplot(self.clumpy, self.correlated, self.unusual)

    @staticmethod
    def load(d: dict) :#-> 'AutoVizScatterplot':
        return AutoVizScatterplot(**d)


class AutoVizHistogram:
    """

    """
    def __init__(self, spikes, skewed, unusual, gaps) :#-> None:
        self.spikes = spikes
        self.skewed = skewed
        self.unusual = unusual
        self.gaps = gaps

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'AutoVizHistogram':
        return AutoVizHistogram(self.spikes, self.skewed, self.unusual, self.gaps)

    @staticmethod
    def load(d: dict) :#-> 'AutoVizHistogram':
        return AutoVizHistogram(**d)


class AutoVizBoxplot:
    """

    """
    def __init__(self, disparate, heteroscedastic) :#-> None:
        self.disparate = disparate
        self.heteroscedastic = heteroscedastic

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'AutoVizBoxplot':
        return AutoVizBoxplot(self.disparate, self.heteroscedastic)

    @staticmethod
    def load(d: dict) :#-> 'AutoVizBoxplot':
        return AutoVizBoxplot(**d)


class AutoVizBiplot:
    """

    """
    def __init__(self, components, loadings, number_of_rows, number_of_columns, component_names, counts) :#-> None:
        self.components = components
        self.loadings = loadings
        self.number_of_rows = number_of_rows
        self.number_of_columns = number_of_columns
        self.component_names = component_names
        self.counts = counts

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'AutoVizBiplot':
        return AutoVizBiplot(self.components, self.loadings, self.number_of_rows, self.number_of_columns, self.component_names, self.counts)

    @staticmethod
    def load(d: dict) :#-> 'AutoVizBiplot':
        return AutoVizBiplot(**d)


class AutoVizBarcharts:
    """

    """
    def __init__(self, unbalanced) :#-> None:
        self.unbalanced = unbalanced

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'AutoVizBarcharts':
        return AutoVizBarcharts(self.unbalanced)

    @staticmethod
    def load(d: dict) :#-> 'AutoVizBarcharts':
        return AutoVizBarcharts(**d)


class H2OAutoViz:
    """

    """
    def __init__(self, scatterplots, barcharts, histograms, boxplots, outliers, biplot) :#-> None:
        self.scatterplots = scatterplots
        self.barcharts = barcharts
        self.histograms = histograms
        self.boxplots = boxplots
        self.outliers = outliers
        self.biplot = biplot

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['scatterplots'] = self.scatterplots.dump()
        d['barcharts'] = self.barcharts.dump()
        d['histograms'] = self.histograms.dump()
        d['boxplots'] = self.boxplots.dump()
        d['biplot'] = self.biplot.dump()
        return d

    def clone(self) :#-> 'H2OAutoViz':
        return H2OAutoViz(self.scatterplots, self.barcharts, self.histograms, self.boxplots, self.outliers, self.biplot)

    @staticmethod
    def load(d: dict) :#-> 'H2OAutoViz':
        d['scatterplots'] = AutoVizScatterplot.load(d['scatterplots'])
        d['barcharts'] = AutoVizBarcharts.load(d['barcharts'])
        d['histograms'] = AutoVizHistogram.load(d['histograms'])
        d['boxplots'] = AutoVizBoxplot.load(d['boxplots'])
        d['biplot'] = AutoVizBiplot.load(d['biplot'])
        return H2OAutoViz(**d)


class Scorer:
    """

    """
    def __init__(self, name, maximize, for_regression, for_binomial, for_multiclass, limit_type, description) :#-> None:
        self.name = name
        self.maximize = maximize
        self.for_regression = for_regression
        self.for_binomial = for_binomial
        self.for_multiclass = for_multiclass
        self.limit_type = limit_type
        self.description = description

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'Scorer':
        return Scorer(self.name, self.maximize, self.for_regression, self.for_binomial, self.for_multiclass, self.limit_type, self.description)

    @staticmethod
    def load(d: dict) :#-> 'Scorer':
        return Scorer(**d)


class DatasetNumericColumnStats:
    """

    """
    def __init__(self, count, mean, std, min, max, unique, freq, hist_ticks, hist_counts) :#-> None:
        self.count = count
        self.mean = mean
        self.std = std
        self.min = min
        self.max = max
        self.unique = unique
        self.freq = freq
        self.hist_ticks = hist_ticks
        self.hist_counts = hist_counts

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'DatasetNumericColumnStats':
        return DatasetNumericColumnStats(self.count, self.mean, self.std, self.min, self.max, self.unique, self.freq, self.hist_ticks, self.hist_counts)

    @staticmethod
    def load(d: dict) :#-> 'DatasetNumericColumnStats':
        return DatasetNumericColumnStats(**d)


class DatasetNonNumericColumnStats:
    """

    """
    def __init__(self, count, unique, top, freq, hist_ticks, hist_counts) :#-> None:
        self.count = count
        self.unique = unique
        self.top = top
        self.freq = freq
        self.hist_ticks = hist_ticks
        self.hist_counts = hist_counts

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'DatasetNonNumericColumnStats':
        return DatasetNonNumericColumnStats(self.count, self.unique, self.top, self.freq, self.hist_ticks, self.hist_counts)

    @staticmethod
    def load(d: dict) :#-> 'DatasetNonNumericColumnStats':
        return DatasetNonNumericColumnStats(**d)


class DatasetColumnStats:
    """

    """
    def __init__(self, is_numeric, num_classes, numeric, non_numeric) :#-> None:
        self.is_numeric = is_numeric
        self.num_classes = num_classes
        self.numeric = numeric
        self.non_numeric = non_numeric

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['numeric'] = self.numeric.dump()
        d['non_numeric'] = self.non_numeric.dump()
        return d

    def clone(self) :#-> 'DatasetColumnStats':
        return DatasetColumnStats(self.is_numeric, self.num_classes, self.numeric, self.non_numeric)

    @staticmethod
    def load(d: dict) :#-> 'DatasetColumnStats':
        d['numeric'] = DatasetNumericColumnStats.load(d['numeric'])
        d['non_numeric'] = DatasetNonNumericColumnStats.load(d['non_numeric'])
        return DatasetColumnStats(**d)


class DatasetColumn:
    """

    """
    def __init__(self, name, data_type, stats, data) :#-> None:
        self.name = name
        self.data_type = data_type
        self.stats = stats
        self.data = data

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['stats'] = self.stats.dump()
        return d

    def clone(self) :#-> 'DatasetColumn':
        return DatasetColumn(self.name, self.data_type, self.stats, self.data)

    @staticmethod
    def load(d: dict) :#-> 'DatasetColumn':
        d['stats'] = DatasetColumnStats.load(d['stats'])
        return DatasetColumn(**d)


class Dataset:
    """

    """
    def __init__(self, key, name, file_path, file_size, bin_file_path, parser_type, row_count, columns, original_frame, aggregated_frame, mapping_frame, uploaded) :#-> None:
        self.key = key
        self.name = name
        self.file_path = file_path
        self.file_size = file_size
        self.bin_file_path = bin_file_path
        self.parser_type = parser_type
        self.row_count = row_count
        self.columns = columns
        self.original_frame = original_frame
        self.aggregated_frame = aggregated_frame
        self.mapping_frame = mapping_frame
        self.uploaded = uploaded

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['columns'] = [a.dump() for a in self.columns]
        return d

    def clone(self) :#-> 'Dataset':
        return Dataset(self.key, self.name, self.file_path, self.file_size, self.bin_file_path, self.parser_type, self.row_count, self.columns, self.original_frame, self.aggregated_frame, self.mapping_frame, self.uploaded)

    @staticmethod
    def load(d: dict) :#-> 'Dataset':
        d['columns'] = [DatasetColumn.load(a) for a in d['columns']]
        return Dataset(**d)


class DatasetSummary:
    """

    """
    def __init__(self, key, name, file_path, file_size, parser_type, row_count, column_count, import_status, import_error, aggregation_status, aggregation_error, aggregated_frame, mapping_frame, uploaded) :#-> None:
        self.key = key
        self.name = name
        self.file_path = file_path
        self.file_size = file_size
        self.parser_type = parser_type
        self.row_count = row_count
        self.column_count = column_count
        self.import_status = import_status
        self.import_error = import_error
        self.aggregation_status = aggregation_status
        self.aggregation_error = aggregation_error
        self.aggregated_frame = aggregated_frame
        self.mapping_frame = mapping_frame
        self.uploaded = uploaded

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'DatasetSummary':
        return DatasetSummary(self.key, self.name, self.file_path, self.file_size, self.parser_type, self.row_count, self.column_count, self.import_status, self.import_error, self.aggregation_status, self.aggregation_error, self.aggregated_frame, self.mapping_frame, self.uploaded)

    @staticmethod
    def load(d: dict) :#-> 'DatasetSummary':
        return DatasetSummary(**d)


class DatasetJob:
    """

    """
    def __init__(self, progress, status, error, message, aggregation_status, aggregation_error, entity, created, uploaded) :#-> None:
        self.progress = progress
        self.status = status
        self.error = error
        self.message = message
        self.aggregation_status = aggregation_status
        self.aggregation_error = aggregation_error
        self.entity = entity
        self.created = created
        self.uploaded = uploaded

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['entity'] = self.entity.dump()
        return d

    def clone(self) :#-> 'DatasetJob':
        return DatasetJob(self.progress, self.status, self.error, self.message, self.aggregation_status, self.aggregation_error, self.entity, self.created, self.uploaded)

    @staticmethod
    def load(d: dict) :#-> 'DatasetJob':
        d['entity'] = Dataset.load(d['entity'])
        return DatasetJob(**d)


class AutoVizSummary:
    """

    """
    def __init__(self, key, dataset_name, dataset_key, dataset_path, progress, status, message, training_duration) :#-> None:
        self.key = key
        self.dataset_name = dataset_name
        self.dataset_key = dataset_key
        self.dataset_path = dataset_path
        self.progress = progress
        self.status = status
        self.message = message
        self.training_duration = training_duration

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'AutoVizSummary':
        return AutoVizSummary(self.key, self.dataset_name, self.dataset_key, self.dataset_path, self.progress, self.status, self.message, self.training_duration)

    @staticmethod
    def load(d: dict) :#-> 'AutoVizSummary':
        return AutoVizSummary(**d)


class AutoVizJob:
    """

    """
    def __init__(self, progress, status, error, message, entity, created, finished, key, dataset_key) :#-> None:
        self.progress = progress
        self.status = status
        self.error = error
        self.message = message
        self.entity = entity
        self.created = created
        self.finished = finished
        self.key = key
        self.dataset_key = dataset_key

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['entity'] = self.entity.dump()
        return d

    def clone(self) :#-> 'AutoVizJob':
        return AutoVizJob(self.progress, self.status, self.error, self.message, self.entity, self.created, self.finished, self.key, self.dataset_key)

    @staticmethod
    def load(d: dict) :#-> 'AutoVizJob':
        d['entity'] = H2OAutoViz.load(d['entity'])
        return AutoVizJob(**d)


class ScatterPlotJob:
    """

    """
    def __init__(self, progress, status, error, message, entity, created) :#-> None:
        self.progress = progress
        self.status = status
        self.error = error
        self.message = message
        self.entity = entity
        self.created = created

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['entity'] = self.entity.dump()
        return d

    def clone(self) :#-> 'ScatterPlotJob':
        return ScatterPlotJob(self.progress, self.status, self.error, self.message, self.entity, self.created)

    @staticmethod
    def load(d: dict) :#-> 'ScatterPlotJob':
        d['entity'] = H2OPlot.load(d['entity'])
        return ScatterPlotJob(**d)


class HistogramJob:
    """

    """
    def __init__(self, progress, status, error, message, entity, created) :#-> None:
        self.progress = progress
        self.status = status
        self.error = error
        self.message = message
        self.entity = entity
        self.created = created

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['entity'] = self.entity.dump()
        return d

    def clone(self) :#-> 'HistogramJob':
        return HistogramJob(self.progress, self.status, self.error, self.message, self.entity, self.created)

    @staticmethod
    def load(d: dict) :#-> 'HistogramJob':
        d['entity'] = Histogram.load(d['entity'])
        return HistogramJob(**d)


class VisStatsJob:
    """

    """
    def __init__(self, progress, status, error, message, entity, created) :#-> None:
        self.progress = progress
        self.status = status
        self.error = error
        self.message = message
        self.entity = entity
        self.created = created

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['entity'] = self.entity.dump()
        return d

    def clone(self) :#-> 'VisStatsJob':
        return VisStatsJob(self.progress, self.status, self.error, self.message, self.entity, self.created)

    @staticmethod
    def load(d: dict) :#-> 'VisStatsJob':
        d['entity'] = H2OVisStats.load(d['entity'])
        return VisStatsJob(**d)


class BoxplotJob:
    """

    """
    def __init__(self, progress, status, error, message, entity, created) :#-> None:
        self.progress = progress
        self.status = status
        self.error = error
        self.message = message
        self.entity = entity
        self.created = created

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['entity'] = self.entity.dump()
        return d

    def clone(self) :#-> 'BoxplotJob':
        return BoxplotJob(self.progress, self.status, self.error, self.message, self.entity, self.created)

    @staticmethod
    def load(d: dict) :#-> 'BoxplotJob':
        d['entity'] = H2OBoxplot.load(d['entity'])
        return BoxplotJob(**d)


class DotplotJob:
    """

    """
    def __init__(self, progress, status, error, message, entity, created) :#-> None:
        self.progress = progress
        self.status = status
        self.error = error
        self.message = message
        self.entity = entity
        self.created = created

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['entity'] = self.entity.dump()
        return d

    def clone(self) :#-> 'DotplotJob':
        return DotplotJob(self.progress, self.status, self.error, self.message, self.entity, self.created)

    @staticmethod
    def load(d: dict) :#-> 'DotplotJob':
        d['entity'] = H2ODotplot.load(d['entity'])
        return DotplotJob(**d)


class HeatMapJob:
    """

    """
    def __init__(self, progress, status, error, message, entity, created) :#-> None:
        self.progress = progress
        self.status = status
        self.error = error
        self.message = message
        self.entity = entity
        self.created = created

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['entity'] = self.entity.dump()
        return d

    def clone(self) :#-> 'HeatMapJob':
        return HeatMapJob(self.progress, self.status, self.error, self.message, self.entity, self.created)

    @staticmethod
    def load(d: dict) :#-> 'HeatMapJob':
        d['entity'] = H2OHeatMap.load(d['entity'])
        return HeatMapJob(**d)


class NetworkJob:
    """

    """
    def __init__(self, progress, status, error, message, entity, created) :#-> None:
        self.progress = progress
        self.status = status
        self.error = error
        self.message = message
        self.entity = entity
        self.created = created

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['entity'] = self.entity.dump()
        return d

    def clone(self) :#-> 'NetworkJob':
        return NetworkJob(self.progress, self.status, self.error, self.message, self.entity, self.created)

    @staticmethod
    def load(d: dict) :#-> 'NetworkJob':
        d['entity'] = H2ONetwork.load(d['entity'])
        return NetworkJob(**d)


class ParallelCoordinatesPlotJob:
    """

    """
    def __init__(self, progress, status, error, message, entity, created) :#-> None:
        self.progress = progress
        self.status = status
        self.error = error
        self.message = message
        self.entity = entity
        self.created = created

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['entity'] = self.entity.dump()
        return d

    def clone(self) :#-> 'ParallelCoordinatesPlotJob':
        return ParallelCoordinatesPlotJob(self.progress, self.status, self.error, self.message, self.entity, self.created)

    @staticmethod
    def load(d: dict) :#-> 'ParallelCoordinatesPlotJob':
        d['entity'] = H2OParallelCoordinatesPlot.load(d['entity'])
        return ParallelCoordinatesPlotJob(**d)


class BarchartJob:
    """

    """
    def __init__(self, progress, status, error, message, entity, created) :#-> None:
        self.progress = progress
        self.status = status
        self.error = error
        self.message = message
        self.entity = entity
        self.created = created

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['entity'] = self.entity.dump()
        return d

    def clone(self) :#-> 'BarchartJob':
        return BarchartJob(self.progress, self.status, self.error, self.message, self.entity, self.created)

    @staticmethod
    def load(d: dict) :#-> 'BarchartJob':
        d['entity'] = H2OBarchart.load(d['entity'])
        return BarchartJob(**d)


class OutliersJob:
    """

    """
    def __init__(self, progress, status, error, message, entity, created) :#-> None:
        self.progress = progress
        self.status = status
        self.error = error
        self.message = message
        self.entity = entity
        self.created = created

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['entity'] = self.entity.dump()
        return d

    def clone(self) :#-> 'OutliersJob':
        return OutliersJob(self.progress, self.status, self.error, self.message, self.entity, self.created)

    @staticmethod
    def load(d: dict) :#-> 'OutliersJob':
        d['entity'] = H2OOutliers.load(d['entity'])
        return OutliersJob(**d)


class FileSearchResult:
    """

    """
    def __init__(self, type, name, extra) :#-> None:
        self.type = type
        self.name = name
        self.extra = extra

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'FileSearchResult':
        return FileSearchResult(self.type, self.name, self.extra)

    @staticmethod
    def load(d: dict) :#-> 'FileSearchResult':
        return FileSearchResult(**d)


class FileSearchResults:
    """

    """
    def __init__(self, dir, entries) :#-> None:
        self.dir = dir
        self.entries = entries

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['entries'] = [a.dump() for a in self.entries]
        return d

    def clone(self) :#-> 'FileSearchResults':
        return FileSearchResults(self.dir, self.entries)

    @staticmethod
    def load(d: dict) :#-> 'FileSearchResults':
        d['entries'] = [FileSearchResult.load(a) for a in d['entries']]
        return FileSearchResults(**d)


class ModelParameters:
    """

    """
    def __init__(self, dataset_key, resumed_model_key, target_col, weight_col, fold_col, orig_time_col, time_col, is_classification, cols_to_drop, validset_key, testset_key, enable_gpus, seed, accuracy, time, interpretability, scorer, time_groups_columns, time_period_in_seconds, num_prediction_periods, num_gap_periods, is_timeseries, config_overrides) :#-> None:
        self.dataset_key = dataset_key
        self.resumed_model_key = resumed_model_key
        self.target_col = target_col
        self.weight_col = weight_col
        self.fold_col = fold_col
        self.orig_time_col = orig_time_col
        self.time_col = time_col
        self.is_classification = is_classification
        self.cols_to_drop = cols_to_drop
        self.validset_key = validset_key
        self.testset_key = testset_key
        self.enable_gpus = enable_gpus
        self.seed = seed
        self.accuracy = accuracy
        self.time = time
        self.interpretability = interpretability
        self.scorer = scorer
        self.time_groups_columns = time_groups_columns
        self.time_period_in_seconds = time_period_in_seconds
        self.num_prediction_periods = num_prediction_periods
        self.num_gap_periods = num_gap_periods
        self.is_timeseries = is_timeseries
        self.config_overrides = config_overrides

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'ModelParameters':
        return ModelParameters(self.dataset_key, self.resumed_model_key, self.target_col, self.weight_col, self.fold_col, self.orig_time_col, self.time_col, self.is_classification, self.cols_to_drop, self.validset_key, self.testset_key, self.enable_gpus, self.seed, self.accuracy, self.time, self.interpretability, self.scorer, self.time_groups_columns, self.time_period_in_seconds, self.num_prediction_periods, self.num_gap_periods, self.is_timeseries, self.config_overrides)

    @staticmethod
    def load(d: dict) :#-> 'ModelParameters':
        return ModelParameters(**d)


class ListDatasetsRequest:
    """

    """
    def __init__(self, offset, limit) :#-> None:
        self.offset = offset
        self.limit = limit

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'ListDatasetsRequest':
        return ListDatasetsRequest(self.offset, self.limit)

    @staticmethod
    def load(d: dict) :#-> 'ListDatasetsRequest':
        return ListDatasetsRequest(**d)


class ListDatasetsResponse:
    """

    """
    def __init__(self, datasets) :#-> None:
        self.datasets = datasets

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['datasets'] = [a.dump() for a in self.datasets]
        return d

    def clone(self) :#-> 'ListDatasetsResponse':
        return ListDatasetsResponse(self.datasets)

    @staticmethod
    def load(d: dict) :#-> 'ListDatasetsResponse':
        d['datasets'] = [Dataset.load(a) for a in d['datasets']]
        return ListDatasetsResponse(**d)


class VarImpTable:
    """

    """
    def __init__(self, gain, interaction, description) :#-> None:
        self.gain = gain
        self.interaction = interaction
        self.description = description

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'VarImpTable':
        return VarImpTable(self.gain, self.interaction, self.description)

    @staticmethod
    def load(d: dict) :#-> 'VarImpTable':
        return VarImpTable(**d)


class ScoresTable:
    """

    """
    def __init__(self, best, iteration, score, model_types) :#-> None:
        self.best = best
        self.iteration = iteration
        self.score = score
        self.model_types = model_types

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'ScoresTable':
        return ScoresTable(self.best, self.iteration, self.score, self.model_types)

    @staticmethod
    def load(d: dict) :#-> 'ScoresTable':
        return ScoresTable(**d)


class TraceEvent:
    """

    """
    def __init__(self, name, ph, ts, ppid, pid, tid, args) :#-> None:
        self.name = name
        self.ph = ph
        self.ts = ts
        self.ppid = ppid
        self.pid = pid
        self.tid = tid
        self.args = args

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'TraceEvent':
        return TraceEvent(self.name, self.ph, self.ts, self.ppid, self.pid, self.tid, self.args)

    @staticmethod
    def load(d: dict) :#-> 'TraceEvent':
        return TraceEvent(**d)


class TraceProgress:
    """

    """
    def __init__(self, trace_events) :#-> None:
        self.trace_events = trace_events

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['trace_events'] = [a.dump() for a in self.trace_events]
        return d

    def clone(self) :#-> 'TraceProgress':
        return TraceProgress(self.trace_events)

    @staticmethod
    def load(d: dict) :#-> 'TraceProgress':
        d['trace_events'] = [TraceEvent.load(a) for a in d['trace_events']]
        return TraceProgress(**d)


class ModelTraceEvents:
    """

    """
    def __init__(self, events, done) :#-> None:
        self.events = events
        self.done = done

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['events'] = [a.dump() for a in self.events]
        return d

    def clone(self) :#-> 'ModelTraceEvents':
        return ModelTraceEvents(self.events, self.done)

    @staticmethod
    def load(d: dict) :#-> 'ModelTraceEvents':
        d['events'] = [TraceEvent.load(a) for a in d['events']]
        return ModelTraceEvents(**d)


class AutoDLInit:
    """

    """
    def __init__(self, scorer) :#-> None:
        self.scorer = scorer

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'AutoDLInit':
        return AutoDLInit(self.scorer)

    @staticmethod
    def load(d: dict) :#-> 'AutoDLInit':
        return AutoDLInit(**d)


class AutoDLProgress:
    """

    """
    def __init__(self, message, iteration, max_iterations, progress, importances, scores, score, score_mean, score_sd, total_features, roc, gains, act_vs_pred) :#-> None:
        self.message = message
        self.iteration = iteration
        self.max_iterations = max_iterations
        self.progress = progress
        self.importances = importances
        self.scores = scores
        self.score = score
        self.score_mean = score_mean
        self.score_sd = score_sd
        self.total_features = total_features
        self.roc = roc
        self.gains = gains
        self.act_vs_pred = act_vs_pred

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['importances'] = self.importances.dump()
        d['scores'] = self.scores.dump()
        d['roc'] = self.roc.dump()
        d['gains'] = self.gains.dump()
        d['act_vs_pred'] = self.act_vs_pred.dump()
        return d

    def clone(self) :#-> 'AutoDLProgress':
        return AutoDLProgress(self.message, self.iteration, self.max_iterations, self.progress, self.importances, self.scores, self.score, self.score_mean, self.score_sd, self.total_features, self.roc, self.gains, self.act_vs_pred)

    @staticmethod
    def load(d: dict) :#-> 'AutoDLProgress':
        d['importances'] = VarImpTable.load(d['importances'])
        d['scores'] = ScoresTable.load(d['scores'])
        d['roc'] = ROC.load(d['roc'])
        d['gains'] = GainLift.load(d['gains'])
        d['act_vs_pred'] = ActVsPred.load(d['act_vs_pred'])
        return AutoDLProgress(**d)


class GainLift:
    """

    """
    def __init__(self, quantiles, gains, lifts) :#-> None:
        self.quantiles = quantiles
        self.gains = gains
        self.lifts = lifts

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'GainLift':
        return GainLift(self.quantiles, self.gains, self.lifts)

    @staticmethod
    def load(d: dict) :#-> 'GainLift':
        return GainLift(**d)


class ROC:
    """

    """
    def __init__(self, auc, aucpr, thresholds, threshold_cms, argmax_cm) :#-> None:
        self.auc = auc
        self.aucpr = aucpr
        self.thresholds = thresholds
        self.threshold_cms = threshold_cms
        self.argmax_cm = argmax_cm

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['threshold_cms'] = [a.dump() for a in self.threshold_cms]
        d['argmax_cm'] = self.argmax_cm.dump()
        return d

    def clone(self) :#-> 'ROC':
        return ROC(self.auc, self.aucpr, self.thresholds, self.threshold_cms, self.argmax_cm)

    @staticmethod
    def load(d: dict) :#-> 'ROC':
        d['threshold_cms'] = [ConfusionMatrix.load(a) for a in d['threshold_cms']]
        d['argmax_cm'] = ConfusionMatrix.load(d['argmax_cm'])
        return ROC(**d)


class ActVsPred:
    """

    """
    def __init__(self, actual, predicted) :#-> None:
        self.actual = actual
        self.predicted = predicted

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'ActVsPred':
        return ActVsPred(self.actual, self.predicted)

    @staticmethod
    def load(d: dict) :#-> 'ActVsPred':
        return ActVsPred(**d)


class ConfusionMatrix:
    """

    """
    def __init__(self, labels, matrix, row_counts, col_counts, miss_counts) :#-> None:
        self.labels = labels
        self.matrix = matrix
        self.row_counts = row_counts
        self.col_counts = col_counts
        self.miss_counts = miss_counts

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'ConfusionMatrix':
        return ConfusionMatrix(self.labels, self.matrix, self.row_counts, self.col_counts, self.miss_counts)

    @staticmethod
    def load(d: dict) :#-> 'ConfusionMatrix':
        return ConfusionMatrix(**d)


class TrainingColumn:
    """

    """
    def __init__(self, name, dtype, typecode, is_numeric, is_integer, min, max, has_na, sample_levels, datetime_format, raw_name) :#-> None:
        self.name = name
        self.dtype = dtype
        self.typecode = typecode
        self.is_numeric = is_numeric
        self.is_integer = is_integer
        self.min = min
        self.max = max
        self.has_na = has_na
        self.sample_levels = sample_levels
        self.datetime_format = datetime_format
        self.raw_name = raw_name

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'TrainingColumn':
        return TrainingColumn(self.name, self.dtype, self.typecode, self.is_numeric, self.is_integer, self.min, self.max, self.has_na, self.sample_levels, self.datetime_format, self.raw_name)

    @staticmethod
    def load(d: dict) :#-> 'TrainingColumn':
        return TrainingColumn(**d)


class ModelTrainingSchema:
    """

    """
    def __init__(self, columns, transformed_columns, target, is_classification, labels, missing_values) :#-> None:
        self.columns = columns
        self.transformed_columns = transformed_columns
        self.target = target
        self.is_classification = is_classification
        self.labels = labels
        self.missing_values = missing_values

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['columns'] = [a.dump() for a in self.columns]
        return d

    def clone(self) :#-> 'ModelTrainingSchema':
        return ModelTrainingSchema(self.columns, self.transformed_columns, self.target, self.is_classification, self.labels, self.missing_values)

    @staticmethod
    def load(d: dict) :#-> 'ModelTrainingSchema':
        d['columns'] = [TrainingColumn.load(a) for a in d['columns']]
        return ModelTrainingSchema(**d)


class AutoDLResult:
    """

    """
    def __init__(self, log_file_path, pickle_path, summary_path, train_predictions_path, valid_predictions_path, test_predictions_path, unfitted_pipeline_path, fitted_model_path, scoring_pipeline_path, mojo_pipeline_path, valid_score, valid_score_sd, valid_roc, valid_gains, valid_act_vs_pred, test_score, test_score_sd, test_roc, test_gains, test_act_vs_pred, labels, ids_col) :#-> None:
        self.log_file_path = log_file_path
        self.pickle_path = pickle_path
        self.summary_path = summary_path
        self.train_predictions_path = train_predictions_path
        self.valid_predictions_path = valid_predictions_path
        self.test_predictions_path = test_predictions_path
        self.unfitted_pipeline_path = unfitted_pipeline_path
        self.fitted_model_path = fitted_model_path
        self.scoring_pipeline_path = scoring_pipeline_path
        self.mojo_pipeline_path = mojo_pipeline_path
        self.valid_score = valid_score
        self.valid_score_sd = valid_score_sd
        self.valid_roc = valid_roc
        self.valid_gains = valid_gains
        self.valid_act_vs_pred = valid_act_vs_pred
        self.test_score = test_score
        self.test_score_sd = test_score_sd
        self.test_roc = test_roc
        self.test_gains = test_gains
        self.test_act_vs_pred = test_act_vs_pred
        self.labels = labels
        self.ids_col = ids_col

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['valid_roc'] = self.valid_roc.dump()
        d['valid_gains'] = self.valid_gains.dump()
        d['valid_act_vs_pred'] = self.valid_act_vs_pred.dump()
        d['test_roc'] = self.test_roc.dump()
        d['test_gains'] = self.test_gains.dump()
        d['test_act_vs_pred'] = self.test_act_vs_pred.dump()
        return d

    def clone(self) :#-> 'AutoDLResult':
        return AutoDLResult(self.log_file_path, self.pickle_path, self.summary_path, self.train_predictions_path, self.valid_predictions_path, self.test_predictions_path, self.unfitted_pipeline_path, self.fitted_model_path, self.scoring_pipeline_path, self.mojo_pipeline_path, self.valid_score, self.valid_score_sd, self.valid_roc, self.valid_gains, self.valid_act_vs_pred, self.test_score, self.test_score_sd, self.test_roc, self.test_gains, self.test_act_vs_pred, self.labels, self.ids_col)

    @staticmethod
    def load(d: dict) :#-> 'AutoDLResult':
        d['valid_roc'] = ROC.load(d['valid_roc'])
        d['valid_gains'] = GainLift.load(d['valid_gains'])
        d['valid_act_vs_pred'] = ActVsPred.load(d['valid_act_vs_pred'])
        d['test_roc'] = ROC.load(d['test_roc'])
        d['test_gains'] = GainLift.load(d['test_gains'])
        d['test_act_vs_pred'] = ActVsPred.load(d['test_act_vs_pred'])
        return AutoDLResult(**d)


class MLIProgress:
    """

    """
    def __init__(self, progress, msg, done) :#-> None:
        self.progress = progress
        self.msg = msg
        self.done = done

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'MLIProgress':
        return MLIProgress(self.progress, self.msg, self.done)

    @staticmethod
    def load(d: dict) :#-> 'MLIProgress':
        return MLIProgress(**d)


class H2OProgress:
    """

    """
    def __init__(self, progress, msg, done) :#-> None:
        self.progress = progress
        self.msg = msg
        self.done = done

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'H2OProgress':
        return H2OProgress(self.progress, self.msg, self.done)

    @staticmethod
    def load(d: dict) :#-> 'H2OProgress':
        return H2OProgress(**d)


class SystemStats:
    """

    """
    def __init__(self, kind, cpu, mem, per) :#-> None:
        self.kind = kind
        self.cpu = cpu
        self.mem = mem
        self.per = per

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'SystemStats':
        return SystemStats(self.kind, self.cpu, self.mem, self.per)

    @staticmethod
    def load(d: dict) :#-> 'SystemStats':
        return SystemStats(**d)


class Model:
    """

    """
    def __init__(self, key, description, dataset_name, parameters, log_file_path, pickle_path, autoreport_path, summary_path, train_predictions_path, valid_predictions_path, test_predictions_path, unfitted_pipeline_path, fitted_model_path, scoring_pipeline_path, mojo_pipeline_path, valid_score, valid_score_sd, valid_roc, valid_gains, valid_act_vs_pred, test_score, test_score_sd, test_roc, test_gains, test_act_vs_pred, labels, ids_col, scorer, score, iteration_data, trace_events, warnings, training_duration, deprecated, patched_pred_contribs, max_iterations, model_file_size) :#-> None:
        self.key = key
        self.description = description
        self.dataset_name = dataset_name
        self.parameters = parameters
        self.log_file_path = log_file_path
        self.pickle_path = pickle_path
        self.autoreport_path = autoreport_path
        self.summary_path = summary_path
        self.train_predictions_path = train_predictions_path
        self.valid_predictions_path = valid_predictions_path
        self.test_predictions_path = test_predictions_path
        self.unfitted_pipeline_path = unfitted_pipeline_path
        self.fitted_model_path = fitted_model_path
        self.scoring_pipeline_path = scoring_pipeline_path
        self.mojo_pipeline_path = mojo_pipeline_path
        self.valid_score = valid_score
        self.valid_score_sd = valid_score_sd
        self.valid_roc = valid_roc
        self.valid_gains = valid_gains
        self.valid_act_vs_pred = valid_act_vs_pred
        self.test_score = test_score
        self.test_score_sd = test_score_sd
        self.test_roc = test_roc
        self.test_gains = test_gains
        self.test_act_vs_pred = test_act_vs_pred
        self.labels = labels
        self.ids_col = ids_col
        self.scorer = scorer
        self.score = score
        self.iteration_data = iteration_data
        self.trace_events = trace_events
        self.warnings = warnings
        self.training_duration = training_duration
        self.deprecated = deprecated
        self.patched_pred_contribs = patched_pred_contribs
        self.max_iterations = max_iterations
        self.model_file_size = model_file_size

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['parameters'] = self.parameters.dump()
        d['valid_roc'] = self.valid_roc.dump()
        d['valid_gains'] = self.valid_gains.dump()
        d['valid_act_vs_pred'] = self.valid_act_vs_pred.dump()
        d['test_roc'] = self.test_roc.dump()
        d['test_gains'] = self.test_gains.dump()
        d['test_act_vs_pred'] = self.test_act_vs_pred.dump()
        d['iteration_data'] = [a.dump() for a in self.iteration_data]
        d['trace_events'] = [a.dump() for a in self.trace_events]
        return d

    def clone(self) :#-> 'Model':
        return Model(self.key, self.description, self.dataset_name, self.parameters, self.log_file_path, self.pickle_path, self.autoreport_path, self.summary_path, self.train_predictions_path, self.valid_predictions_path, self.test_predictions_path, self.unfitted_pipeline_path, self.fitted_model_path, self.scoring_pipeline_path, self.mojo_pipeline_path, self.valid_score, self.valid_score_sd, self.valid_roc, self.valid_gains, self.valid_act_vs_pred, self.test_score, self.test_score_sd, self.test_roc, self.test_gains, self.test_act_vs_pred, self.labels, self.ids_col, self.scorer, self.score, self.iteration_data, self.trace_events, self.warnings, self.training_duration, self.deprecated, self.patched_pred_contribs, self.max_iterations, self.model_file_size)

    @staticmethod
    def load(d: dict) :#-> 'Model':
        d['parameters'] = ModelParameters.load(d['parameters'])
        d['valid_roc'] = ROC.load(d['valid_roc'])
        d['valid_gains'] = GainLift.load(d['valid_gains'])
        d['valid_act_vs_pred'] = ActVsPred.load(d['valid_act_vs_pred'])
        d['test_roc'] = ROC.load(d['test_roc'])
        d['test_gains'] = GainLift.load(d['test_gains'])
        d['test_act_vs_pred'] = ActVsPred.load(d['test_act_vs_pred'])
        d['iteration_data'] = [AutoDLProgress.load(a) for a in d['iteration_data']]
        d['trace_events'] = [TraceEvent.load(a) for a in d['trace_events']]
        return Model(**d)


class ModelJob:
    """

    """
    def __init__(self, progress, status, error, message, entity, eta, created) :#-> None:
        self.progress = progress
        self.status = status
        self.error = error
        self.message = message
        self.entity = entity
        self.eta = eta
        self.created = created

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['entity'] = self.entity.dump()
        return d

    def clone(self) :#-> 'ModelJob':
        return ModelJob(self.progress, self.status, self.error, self.message, self.entity, self.eta, self.created)

    @staticmethod
    def load(d: dict) :#-> 'ModelJob':
        d['entity'] = Model.load(d['entity'])
        return ModelJob(**d)


class ImportModelJob:
    """

    """
    def __init__(self, progress, status, error, message, aggregation_status, aggregation_error, entity, created) :#-> None:
        self.progress = progress
        self.status = status
        self.error = error
        self.message = message
        self.aggregation_status = aggregation_status
        self.aggregation_error = aggregation_error
        self.entity = entity
        self.created = created

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['entity'] = self.entity.dump()
        return d

    def clone(self) :#-> 'ImportModelJob':
        return ImportModelJob(self.progress, self.status, self.error, self.message, self.aggregation_status, self.aggregation_error, self.entity, self.created)

    @staticmethod
    def load(d: dict) :#-> 'ImportModelJob':
        d['entity'] = Model.load(d['entity'])
        return ImportModelJob(**d)


class ModelSummary:
    """

    """
    def __init__(self, key, description, dataset_name, parameters, log_file_path, pickle_path, summary_path, train_predictions_path, valid_predictions_path, test_predictions_path, progress, status, training_duration, scorer, score, test_score, deprecated, model_file_size) :#-> None:
        self.key = key
        self.description = description
        self.dataset_name = dataset_name
        self.parameters = parameters
        self.log_file_path = log_file_path
        self.pickle_path = pickle_path
        self.summary_path = summary_path
        self.train_predictions_path = train_predictions_path
        self.valid_predictions_path = valid_predictions_path
        self.test_predictions_path = test_predictions_path
        self.progress = progress
        self.status = status
        self.training_duration = training_duration
        self.scorer = scorer
        self.score = score
        self.test_score = test_score
        self.deprecated = deprecated
        self.model_file_size = model_file_size

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['parameters'] = self.parameters.dump()
        return d

    def clone(self) :#-> 'ModelSummary':
        return ModelSummary(self.key, self.description, self.dataset_name, self.parameters, self.log_file_path, self.pickle_path, self.summary_path, self.train_predictions_path, self.valid_predictions_path, self.test_predictions_path, self.progress, self.status, self.training_duration, self.scorer, self.score, self.test_score, self.deprecated, self.model_file_size)

    @staticmethod
    def load(d: dict) :#-> 'ModelSummary':
        d['parameters'] = ModelParameters.load(d['parameters'])
        return ModelSummary(**d)


class InterpretParameters:
    """

    """
    def __init__(self, dai_model_key, dataset_key, target_col, prediction_col, use_raw_features, nfolds, klime_cluster_col, weight_col, drop_cols, sample, sample_num_rows, qbin_cols, qbin_count, lime_method, dt_tree_depth, config_overrides) :#-> None:
        self.dai_model_key = dai_model_key
        self.dataset_key = dataset_key
        self.target_col = target_col
        self.prediction_col = prediction_col
        self.use_raw_features = use_raw_features
        self.nfolds = nfolds
        self.klime_cluster_col = klime_cluster_col
        self.weight_col = weight_col
        self.drop_cols = drop_cols
        self.sample = sample
        self.sample_num_rows = sample_num_rows
        self.qbin_cols = qbin_cols
        self.qbin_count = qbin_count
        self.lime_method = lime_method
        self.dt_tree_depth = dt_tree_depth
        self.config_overrides = config_overrides

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'InterpretParameters':
        return InterpretParameters(self.dai_model_key, self.dataset_key, self.target_col, self.prediction_col, self.use_raw_features, self.nfolds, self.klime_cluster_col, self.weight_col, self.drop_cols, self.sample, self.sample_num_rows, self.qbin_cols, self.qbin_count, self.lime_method, self.dt_tree_depth, self.config_overrides)

    @staticmethod
    def load(d: dict) :#-> 'InterpretParameters':
        return InterpretParameters(**d)


class InterpretSummary:
    """

    """
    def __init__(self, key, description, dataset_name, parameters, progress, status, training_duration) :#-> None:
        self.key = key
        self.description = description
        self.dataset_name = dataset_name
        self.parameters = parameters
        self.progress = progress
        self.status = status
        self.training_duration = training_duration

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['parameters'] = self.parameters.dump()
        return d

    def clone(self) :#-> 'InterpretSummary':
        return InterpretSummary(self.key, self.description, self.dataset_name, self.parameters, self.progress, self.status, self.training_duration)

    @staticmethod
    def load(d: dict) :#-> 'InterpretSummary':
        d['parameters'] = InterpretParameters.load(d['parameters'])
        return InterpretSummary(**d)


class Prediction:
    """

    """
    def __init__(self, key, model_key, scoring_csv_path, predictions_csv_path) :#-> None:
        self.key = key
        self.model_key = model_key
        self.scoring_csv_path = scoring_csv_path
        self.predictions_csv_path = predictions_csv_path

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'Prediction':
        return Prediction(self.key, self.model_key, self.scoring_csv_path, self.predictions_csv_path)

    @staticmethod
    def load(d: dict) :#-> 'Prediction':
        return Prediction(**d)


class PredictionJob:
    """

    """
    def __init__(self, progress, status, error, message, entity, created) :#-> None:
        self.progress = progress
        self.status = status
        self.error = error
        self.message = message
        self.entity = entity
        self.created = created

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['entity'] = self.entity.dump()
        return d

    def clone(self) :#-> 'PredictionJob':
        return PredictionJob(self.progress, self.status, self.error, self.message, self.entity, self.created)

    @staticmethod
    def load(d: dict) :#-> 'PredictionJob':
        d['entity'] = Prediction.load(d['entity'])
        return PredictionJob(**d)


class AutoReport:
    """

    """
    def __init__(self, key, model_key, report_path) :#-> None:
        self.key = key
        self.model_key = model_key
        self.report_path = report_path

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'AutoReport':
        return AutoReport(self.key, self.model_key, self.report_path)

    @staticmethod
    def load(d: dict) :#-> 'AutoReport':
        return AutoReport(**d)


class AutoReportJob:
    """

    """
    def __init__(self, progress, status, error, message, entity, created) :#-> None:
        self.progress = progress
        self.status = status
        self.error = error
        self.message = message
        self.entity = entity
        self.created = created

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['entity'] = self.entity.dump()
        return d

    def clone(self) :#-> 'AutoReportJob':
        return AutoReportJob(self.progress, self.status, self.error, self.message, self.entity, self.created)

    @staticmethod
    def load(d: dict) :#-> 'AutoReportJob':
        d['entity'] = AutoReport.load(d['entity'])
        return AutoReportJob(**d)


class Transformation:
    """

    """
    def __init__(self, key, model_key, training_input_csv_path, validation_input_csv_path, test_input_csv_path, validation_split_fraction, seed, fold_column, training_output_csv_path, validation_output_csv_path, test_output_csv_path) :#-> None:
        self.key = key
        self.model_key = model_key
        self.training_input_csv_path = training_input_csv_path
        self.validation_input_csv_path = validation_input_csv_path
        self.test_input_csv_path = test_input_csv_path
        self.validation_split_fraction = validation_split_fraction
        self.seed = seed
        self.fold_column = fold_column
        self.training_output_csv_path = training_output_csv_path
        self.validation_output_csv_path = validation_output_csv_path
        self.test_output_csv_path = test_output_csv_path

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'Transformation':
        return Transformation(self.key, self.model_key, self.training_input_csv_path, self.validation_input_csv_path, self.test_input_csv_path, self.validation_split_fraction, self.seed, self.fold_column, self.training_output_csv_path, self.validation_output_csv_path, self.test_output_csv_path)

    @staticmethod
    def load(d: dict) :#-> 'Transformation':
        return Transformation(**d)


class TransformationJob:
    """

    """
    def __init__(self, progress, status, error, message, entity, created) :#-> None:
        self.progress = progress
        self.status = status
        self.error = error
        self.message = message
        self.entity = entity
        self.created = created

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['entity'] = self.entity.dump()
        return d

    def clone(self) :#-> 'TransformationJob':
        return TransformationJob(self.progress, self.status, self.error, self.message, self.entity, self.created)

    @staticmethod
    def load(d: dict) :#-> 'TransformationJob':
        d['entity'] = Transformation.load(d['entity'])
        return TransformationJob(**d)


class ModelDiagnosticsParameters:
    """

    """
    def __init__(self, dai_model_key, testset_key, sample_num_rows, config_overrides) :#-> None:
        self.dai_model_key = dai_model_key
        self.testset_key = testset_key
        self.sample_num_rows = sample_num_rows
        self.config_overrides = config_overrides

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'ModelDiagnosticsParameters':
        return ModelDiagnosticsParameters(self.dai_model_key, self.testset_key, self.sample_num_rows, self.config_overrides)

    @staticmethod
    def load(d: dict) :#-> 'ModelDiagnosticsParameters':
        return ModelDiagnosticsParameters(**d)


class ModelDiagnosticsSummary:
    """

    """
    def __init__(self, key, description, parameters, progress, status, duration) :#-> None:
        self.key = key
        self.description = description
        self.parameters = parameters
        self.progress = progress
        self.status = status
        self.duration = duration

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['parameters'] = self.parameters.dump()
        return d

    def clone(self) :#-> 'ModelDiagnosticsSummary':
        return ModelDiagnosticsSummary(self.key, self.description, self.parameters, self.progress, self.status, self.duration)

    @staticmethod
    def load(d: dict) :#-> 'ModelDiagnosticsSummary':
        d['parameters'] = ModelDiagnosticsParameters.load(d['parameters'])
        return ModelDiagnosticsSummary(**d)


class ModelDiagnostics:
    """

    """
    def __init__(self, key, description, tmp_dir, parameters, duration, test_window_start, test_window_end) :#-> None:
        self.key = key
        self.description = description
        self.tmp_dir = tmp_dir
        self.parameters = parameters
        self.duration = duration
        self.test_window_start = test_window_start
        self.test_window_end = test_window_end

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['parameters'] = self.parameters.dump()
        return d

    def clone(self) :#-> 'ModelDiagnostics':
        return ModelDiagnostics(self.key, self.description, self.tmp_dir, self.parameters, self.duration, self.test_window_start, self.test_window_end)

    @staticmethod
    def load(d: dict) :#-> 'ModelDiagnostics':
        d['parameters'] = ModelDiagnosticsParameters.load(d['parameters'])
        return ModelDiagnostics(**d)


class ModelDiagnosticsJob:
    """

    """
    def __init__(self, progress, status, error, message, entity, created) :#-> None:
        self.progress = progress
        self.status = status
        self.error = error
        self.message = message
        self.entity = entity
        self.created = created

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['entity'] = self.entity.dump()
        return d

    def clone(self) :#-> 'ModelDiagnosticsJob':
        return ModelDiagnosticsJob(self.progress, self.status, self.error, self.message, self.entity, self.created)

    @staticmethod
    def load(d: dict) :#-> 'ModelDiagnosticsJob':
        d['entity'] = ModelDiagnostics.load(d['entity'])
        return ModelDiagnosticsJob(**d)


class Interpretation:
    """

    """
    def __init__(self, key, description, tmp_dir, dataset_name, scoring_package_path, binned_list, labels, parameters, training_duration, log_file_path, lime_rc_csv_path, shapley_rc_csv_path) :#-> None:
        self.key = key
        self.description = description
        self.tmp_dir = tmp_dir
        self.dataset_name = dataset_name
        self.scoring_package_path = scoring_package_path
        self.binned_list = binned_list
        self.labels = labels
        self.parameters = parameters
        self.training_duration = training_duration
        self.log_file_path = log_file_path
        self.lime_rc_csv_path = lime_rc_csv_path
        self.shapley_rc_csv_path = shapley_rc_csv_path

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['parameters'] = self.parameters.dump()
        return d

    def clone(self) :#-> 'Interpretation':
        return Interpretation(self.key, self.description, self.tmp_dir, self.dataset_name, self.scoring_package_path, self.binned_list, self.labels, self.parameters, self.training_duration, self.log_file_path, self.lime_rc_csv_path, self.shapley_rc_csv_path)

    @staticmethod
    def load(d: dict) :#-> 'Interpretation':
        d['parameters'] = InterpretParameters.load(d['parameters'])
        return Interpretation(**d)


class InterpretationJob:
    """

    """
    def __init__(self, progress, h2oprogress, mliprogress, status, error, message, entity, created) :#-> None:
        self.progress = progress
        self.h2oprogress = h2oprogress
        self.mliprogress = mliprogress
        self.status = status
        self.error = error
        self.message = message
        self.entity = entity
        self.created = created

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['h2oprogress'] = self.h2oprogress.dump()
        d['mliprogress'] = self.mliprogress.dump()
        d['entity'] = self.entity.dump()
        return d

    def clone(self) :#-> 'InterpretationJob':
        return InterpretationJob(self.progress, self.h2oprogress, self.mliprogress, self.status, self.error, self.message, self.entity, self.created)

    @staticmethod
    def load(d: dict) :#-> 'InterpretationJob':
        d['h2oprogress'] = H2OProgress.load(d['h2oprogress'])
        d['mliprogress'] = MLIProgress.load(d['mliprogress'])
        d['entity'] = Interpretation.load(d['entity'])
        return InterpretationJob(**d)


class ScoringPipeline:
    """

    """
    def __init__(self, model_key, file_path) :#-> None:
        self.model_key = model_key
        self.file_path = file_path

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'ScoringPipeline':
        return ScoringPipeline(self.model_key, self.file_path)

    @staticmethod
    def load(d: dict) :#-> 'ScoringPipeline':
        return ScoringPipeline(**d)


class MojoPipeline:
    """

    """
    def __init__(self, model_key, file_path) :#-> None:
        self.model_key = model_key
        self.file_path = file_path

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'MojoPipeline':
        return MojoPipeline(self.model_key, self.file_path)

    @staticmethod
    def load(d: dict) :#-> 'MojoPipeline':
        return MojoPipeline(**d)


class ScoringPipelineJob:
    """

    """
    def __init__(self, progress, status, error, message, entity, created) :#-> None:
        self.progress = progress
        self.status = status
        self.error = error
        self.message = message
        self.entity = entity
        self.created = created

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['entity'] = self.entity.dump()
        return d

    def clone(self) :#-> 'ScoringPipelineJob':
        return ScoringPipelineJob(self.progress, self.status, self.error, self.message, self.entity, self.created)

    @staticmethod
    def load(d: dict) :#-> 'ScoringPipelineJob':
        d['entity'] = ScoringPipeline.load(d['entity'])
        return ScoringPipelineJob(**d)


class MojoPipelineJob:
    """

    """
    def __init__(self, progress, status, error, message, entity, created) :#-> None:
        self.progress = progress
        self.status = status
        self.error = error
        self.message = message
        self.entity = entity
        self.created = created

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['entity'] = self.entity.dump()
        return d

    def clone(self) :#-> 'MojoPipelineJob':
        return MojoPipelineJob(self.progress, self.status, self.error, self.message, self.entity, self.created)

    @staticmethod
    def load(d: dict) :#-> 'MojoPipelineJob':
        d['entity'] = MojoPipeline.load(d['entity'])
        return MojoPipelineJob(**d)


class ExemplarRowsResponse:
    """

    """
    def __init__(self, exemplar_id, headers, rows, totalRows) :#-> None:
        self.exemplar_id = exemplar_id
        self.headers = headers
        self.rows = rows
        self.totalRows = totalRows

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'ExemplarRowsResponse':
        return ExemplarRowsResponse(self.exemplar_id, self.headers, self.rows, self.totalRows)

    @staticmethod
    def load(d: dict) :#-> 'ExemplarRowsResponse':
        return ExemplarRowsResponse(**d)


class ConfigItem:
    """

    """
    def __init__(self, name, description, type, val, predefined, interactions) :#-> None:
        self.name = name
        self.description = description
        self.type = type
        self.val = val
        self.predefined = predefined
        self.interactions = interactions

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'ConfigItem':
        return ConfigItem(self.name, self.description, self.type, self.val, self.predefined, self.interactions)

    @staticmethod
    def load(d: dict) :#-> 'ConfigItem':
        return ConfigItem(**d)


class ExperimentPreviewResponse:
    """

    """
    def __init__(self, accuracy, time, interpretability, lines) :#-> None:
        self.accuracy = accuracy
        self.time = time
        self.interpretability = interpretability
        self.lines = lines

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'ExperimentPreviewResponse':
        return ExperimentPreviewResponse(self.accuracy, self.time, self.interpretability, self.lines)

    @staticmethod
    def load(d: dict) :#-> 'ExperimentPreviewResponse':
        return ExperimentPreviewResponse(**d)


class ExperimentPreviewJob:
    """

    """
    def __init__(self, progress, status, error, message, entity, created) :#-> None:
        self.progress = progress
        self.status = status
        self.error = error
        self.message = message
        self.entity = entity
        self.created = created

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['entity'] = self.entity.dump()
        return d

    def clone(self) :#-> 'ExperimentPreviewJob':
        return ExperimentPreviewJob(self.progress, self.status, self.error, self.message, self.entity, self.created)

    @staticmethod
    def load(d: dict) :#-> 'ExperimentPreviewJob':
        d['entity'] = ExperimentPreviewResponse.load(d['entity'])
        return ExperimentPreviewJob(**d)


class UserInfo:
    """

    """
    def __init__(self, name) :#-> None:
        self.name = name

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'UserInfo':
        return UserInfo(self.name)

    @staticmethod
    def load(d: dict) :#-> 'UserInfo':
        return UserInfo(**d)


class TimeSeriesSplitSuggestion:
    """

    """
    def __init__(self, period_ticks, gap_ticks, train_values, valid_values, alpha_values, train_samples, valid_samples, gapped_samples, total_periods, period_size, period_units, default_unit, threshold, test_gap, test_periods) :#-> None:
        self.period_ticks = period_ticks
        self.gap_ticks = gap_ticks
        self.train_values = train_values
        self.valid_values = valid_values
        self.alpha_values = alpha_values
        self.train_samples = train_samples
        self.valid_samples = valid_samples
        self.gapped_samples = gapped_samples
        self.total_periods = total_periods
        self.period_size = period_size
        self.period_units = period_units
        self.default_unit = default_unit
        self.threshold = threshold
        self.test_gap = test_gap
        self.test_periods = test_periods

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        return d

    def clone(self) :#-> 'TimeSeriesSplitSuggestion':
        return TimeSeriesSplitSuggestion(self.period_ticks, self.gap_ticks, self.train_values, self.valid_values, self.alpha_values, self.train_samples, self.valid_samples, self.gapped_samples, self.total_periods, self.period_size, self.period_units, self.default_unit, self.threshold, self.test_gap, self.test_periods)

    @staticmethod
    def load(d: dict) :#-> 'TimeSeriesSplitSuggestion':
        return TimeSeriesSplitSuggestion(**d)


class TimeSeriesSplitSuggestionJob:
    """

    """
    def __init__(self, progress, status, error, message, entity, created) :#-> None:
        self.progress = progress
        self.status = status
        self.error = error
        self.message = message
        self.entity = entity
        self.created = created

    def dump(self) :#-> dict:
        d = {k: v for k, v in vars(self).items()}
        d['entity'] = self.entity.dump()
        return d

    def clone(self) :#-> 'TimeSeriesSplitSuggestionJob':
        return TimeSeriesSplitSuggestionJob(self.progress, self.status, self.error, self.message, self.entity, self.created)

    @staticmethod
    def load(d: dict) :#-> 'TimeSeriesSplitSuggestionJob':
        d['entity'] = TimeSeriesSplitSuggestion.load(d['entity'])
        return TimeSeriesSplitSuggestionJob(**d)

